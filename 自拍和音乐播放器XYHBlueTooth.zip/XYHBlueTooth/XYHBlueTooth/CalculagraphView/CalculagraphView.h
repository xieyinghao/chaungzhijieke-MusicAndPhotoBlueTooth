//
//  CalculagraphView.h
//  YB_ Calculagraph
//
//  Created by rimi on 16/3/23.
//  Copyright © 2016年 wakeup. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CalculagraphView : UIView

@property (nonatomic, assign) NSInteger timeInterval;

- (void)start;  //开始
- (void)suspend;    //暂停
- (void)goOn;   //继续
- (void)stop;   //停止

//手动更新计时器接口 (比如进入后台过后，只需要将计算时间间隔，调用此方法刷新计时器)
- (void)updateCaculagraphWith:(NSTimeInterval)timeInterval;

@end
