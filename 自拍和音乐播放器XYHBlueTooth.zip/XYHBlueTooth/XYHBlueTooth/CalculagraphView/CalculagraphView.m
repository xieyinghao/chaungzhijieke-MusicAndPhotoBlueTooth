//
//  CalculagraphView.m
//  YB_ Calculagraph
//
//  Created by rimi on 16/3/23.
//  Copyright © 2016年 wakeup. All rights reserved.
//

#import "CalculagraphView.h"
#import "CalculagraphSubview.h"

static const CGFloat interval = 10;
#define Width (CGRectGetWidth(self.bounds) / 6 - interval / 3)
#define Height CGRectGetHeight(self.bounds)

@interface CalculagraphView ()

{
    
    NSTimer *_timer;
    
    BOOL _isFirstStart;
    
    BOOL _isMinuteLIncrease;
    BOOL _isHourRIncrease;
    BOOL _isHourLIncrease;
    
    CalculagraphSubview *_hourL;
    CalculagraphSubview *_hourR;
    CalculagraphSubview *_minuteL;
    CalculagraphSubview *_minuteR;
    CalculagraphSubview *_secondL;
    CalculagraphSubview *_secondR;
}

@end

@implementation CalculagraphView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        _isFirstStart = YES;
        
        _hourL = [[CalculagraphSubview alloc] initWithFrame:CGRectMake(0, 0, Width, Height) titleNumberIsTen:YES];
        _hourR = [[CalculagraphSubview alloc] initWithFrame:CGRectMake(Width, 0, Width, Height) titleNumberIsTen:YES];
        
        UILabel *leftLabel = [[UILabel alloc] initWithFrame:CGRectMake(Width * 2, 0, interval, Height)];
        leftLabel.textAlignment = NSTextAlignmentCenter;
        leftLabel.font = [UIFont systemFontOfSize:30];
        leftLabel.textColor = [UIColor purpleColor];
        leftLabel.text = @":";
        
        _minuteL = [[CalculagraphSubview alloc] initWithFrame:CGRectMake(Width * 2 + interval, 0, Width, Height) titleNumberIsTen:NO];
        _minuteR = [[CalculagraphSubview alloc] initWithFrame:CGRectMake(Width * 3 + interval, 0, Width, Height) titleNumberIsTen:YES];
        
        UILabel *rightLabel = [[UILabel alloc] initWithFrame:CGRectMake(Width * 4 + interval, 0, interval, Height)];
        rightLabel.textAlignment = NSTextAlignmentCenter;
        rightLabel.font = [UIFont systemFontOfSize:30];
        rightLabel.textColor = [UIColor purpleColor];
        rightLabel.text = @":";
        
        _secondL = [[CalculagraphSubview alloc] initWithFrame:CGRectMake(Width * 4 + interval * 2, 0, Width, Height) titleNumberIsTen:NO];
        _secondR = [[CalculagraphSubview alloc] initWithFrame:CGRectMake(Width * 5 + interval * 2, 0, Width, Height) titleNumberIsTen:YES];
        
        [self addSubview:_hourL];
        [self addSubview:_hourR];
        [self addSubview:leftLabel];
        [self addSubview:_minuteL];
        [self addSubview:_minuteR];
        [self addSubview:rightLabel];
        [self addSubview:_secondL];
        [self addSubview:_secondR];
        
    }
    return self;
}

#pragma mark *** Public ***
- (void)start {
    if (!_isFirstStart) {
        return;
    }
    
    _isFirstStart = NO;
    _timer = [NSTimer scheduledTimerWithTimeInterval:1.0f target:self selector:@selector(respondsToTimer:) userInfo:nil repeats:YES];
    
    [[NSRunLoop mainRunLoop] addTimer:_timer forMode:NSDefaultRunLoopMode];
    
    _timer.fireDate = [NSDate dateWithTimeIntervalSinceNow:1.0f];
}
- (void)suspend {
    _timer.fireDate = [NSDate distantFuture];
}
- (void)goOn {
    _timer.fireDate = [NSDate dateWithTimeIntervalSinceNow:1.0f];
}
- (void)stop {
    [_timer invalidate];
    
    self.timeInterval = _secondR.recordIncreaseTimes;
    
    [[NSNotificationCenter defaultCenter] postNotificationName:@"stopCalculagraph" object:nil];
    
    _isFirstStart = YES;
}
- (void)updateCaculagraphWith:(NSTimeInterval)timeInterval {
    
    NSInteger interval = timeInterval;
    
    //显示的内容计算
    NSInteger hourInterval = interval / 3600;
    NSInteger minuteInterval = interval % 3600 / 60;
    NSInteger secondInterval = interval % 60;
    
    NSInteger hourIntervalL = hourInterval / 10;
    NSInteger hourIntervalR = hourInterval % 10;
    NSInteger minuteIntervalL = minuteInterval / 10;
    NSInteger minuteIntervalR = minuteInterval % 10;
    NSInteger secondIntervalL = secondInterval / 10;
    NSInteger secondIntervalR = secondInterval % 10;
    
    //记录的次数计算
    _hourL.recordIncreaseTimes = interval / 3600 / 10;
    _hourR.recordIncreaseTimes = interval / 3600;
    _minuteL.recordIncreaseTimes = interval / 60 / 10;
    _minuteR.recordIncreaseTimes = interval / 60;
    _secondL.recordIncreaseTimes = interval / 10;
    _secondR.recordIncreaseTimes = interval;
    
    //更新偏移
    _hourL.scrollView.contentOffset = CGPointMake(0, _hourL.scrollView.bounds.size.height);
    _hourR.scrollView.contentOffset = CGPointMake(0, _hourR.scrollView.bounds.size.height);
    _minuteL.scrollView.contentOffset = CGPointMake(0, _minuteL.scrollView.bounds.size.height);
    _minuteR.scrollView.contentOffset = CGPointMake(0, _minuteR.scrollView.bounds.size.height);
    _secondL.scrollView.contentOffset = CGPointMake(0, _secondL.scrollView.bounds.size.height);
    _secondR.scrollView.contentOffset = CGPointMake(0, _secondR.scrollView.bounds.size.height);
    
    //更新显示的imageNames
    _hourL.imageNames = [NSMutableArray arrayWithArray:[self getTenImageNamesWithNumber:hourIntervalL]];
    [_hourL addTitleToLabel];
    _hourR.imageNames = [NSMutableArray arrayWithArray:[self getTenImageNamesWithNumber:hourIntervalR]];
    [_hourL addTitleToLabel];
    _minuteL.imageNames = [NSMutableArray arrayWithArray:[self getSixImageNamesWithNumber:minuteIntervalL]];
    [_minuteL addTitleToLabel];
    _minuteR.imageNames = [NSMutableArray arrayWithArray:[self getTenImageNamesWithNumber:minuteIntervalR]];
    [_minuteR addTitleToLabel];
    _secondL.imageNames = [NSMutableArray arrayWithArray:[self getSixImageNamesWithNumber:secondIntervalL]];
    [_secondL addTitleToLabel];
    _secondR.imageNames = [NSMutableArray arrayWithArray:[self getTenImageNamesWithNumber:secondIntervalR]];
    [_secondR addTitleToLabel];
    
}

#pragma mark *** Private ***
- (NSMutableArray *)getSixImageNamesWithNumber:(NSInteger)number {
    NSArray *arr = @[@"calculagraph0", @"calculagraph1", @"calculagraph2", @"calculagraph3", @"calculagraph4", @"calculagraph5"];
    NSMutableArray *resultArr = [@[] mutableCopy];
    
    NSInteger firstNumber = number - 1;
    if (firstNumber < 0) {
        firstNumber = 5;
    }
    NSInteger currentNumber = firstNumber;
    
    for (NSInteger i = 0; i < 6; i++) {
        
        if (currentNumber <= 5) {
            
        }else {
            currentNumber = 0;
        }
        [resultArr addObject:arr[currentNumber ++]];
        
    }
    
    return resultArr;
    
}
- (NSMutableArray *)getTenImageNamesWithNumber:(NSInteger)number {
    
    NSArray *arr = @[@"calculagraph0", @"calculagraph1", @"calculagraph2", @"calculagraph3", @"calculagraph4", @"calculagraph5", @"calculagraph6", @"calculagraph7", @"calculagraph8", @"calculagraph9"];
    
    NSMutableArray *resultArr = [@[] mutableCopy];
    
    NSInteger firstNumber = number - 1;
    if (firstNumber < 0) {
        firstNumber = 9;
    }
    NSInteger currentNumber = firstNumber;
    
    for (NSInteger i = 0; i < 10; i++) {
        
        if (currentNumber <= 9) {
            
        }else {
            currentNumber = 0;
        }
        [resultArr addObject:arr[currentNumber ++]];
        
    }
    
    return resultArr;
}
- (void)respondsToTimer:(NSTimer *)timer {
    
    [_secondR increase];
    
    if (_secondR.recordIncreaseTimes % 10 == 0 && _secondR.recordIncreaseTimes != 0) {
        [_secondL increase];
    }
    
    if (_secondL.recordIncreaseTimes % 6 == 0 && _secondL.recordIncreaseTimes != 0 && _secondR.recordIncreaseTimes % 10 == 0) {
        [_minuteR increase];
        _isMinuteLIncrease = YES;
    }
    
    if (_minuteR.recordIncreaseTimes % 10 == 0 && _minuteR.recordIncreaseTimes != 0) {
        
        if (_isMinuteLIncrease) {
            [_minuteL increase];
            _isMinuteLIncrease = NO;
            _isHourRIncrease = YES;
        }
    }
    
    if (_minuteL.recordIncreaseTimes % 6 == 0 && _minuteL.recordIncreaseTimes != 0 && _minuteR.recordIncreaseTimes % 10 == 0) {
        if (_isHourRIncrease) {
            [_hourR increase];
            _isHourRIncrease = NO;
            _isHourLIncrease = YES;
        }
    }
    
    if (_hourR.recordIncreaseTimes % 10 == 0 && _hourR.recordIncreaseTimes != 0) {
        if (_isHourLIncrease) {
            [_hourL increase];
            _isHourLIncrease = NO;
        }
    }
    
}

@end
