//
//  CalculagraphSubview.m
//  YB_ Calculagraph
//
//  Created by rimi on 16/3/23.
//  Copyright © 2016年 wakeup. All rights reserved.
//

#import "CalculagraphSubview.h"

#define RGB_COLOR(_R,_G,_B,_A) [UIColor colorWithRed:_R/255.0 green:_G/255.0 blue:_B/255.0 alpha:_A]

@interface CalculagraphSubview () <UIScrollViewDelegate>

{
    BOOL _isten;
    BOOL _isScrollViewDidEndScrollingAnimation;
    
    NSMutableArray *_images;
}

@end

@implementation CalculagraphSubview

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}
#pragma mark *** Init ***
- (instancetype)initWithFrame:(CGRect)frame titleNumberIsTen:(BOOL)isTen{
    if (self = [super initWithFrame:frame]) {
        
        _isten = isTen;
        
        _images = [@[] mutableCopy];
        
        if (isTen) {
            self.imageNames = [NSMutableArray arrayWithArray:@[@"calculagraph9", @"calculagraph0", @"calculagraph1", @"calculagraph2", @"calculagraph3", @"calculagraph4", @"calculagraph5", @"calculagraph6", @"calculagraph7", @"calculagraph8"]];
        }else {
            self.imageNames = [NSMutableArray arrayWithArray:@[@"calculagraph5", @"calculagraph0", @"calculagraph1", @"calculagraph2", @"calculagraph3", @"calculagraph4"]];
        }

        for (int i = 0; i < 3; i ++) {
            UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(1, CGRectGetHeight(self.scrollView.bounds) * i + 2, CGRectGetWidth(self.scrollView.bounds) - 2, CGRectGetHeight(self.scrollView.bounds) - 4)];
            
            imageView.layer.cornerRadius = CGRectGetWidth(imageView.frame) / 2;
            imageView.layer.masksToBounds = YES;
            imageView.backgroundColor = [UIColor whiteColor];
            [_images addObject:imageView];
            [self.scrollView addSubview:imageView];
        }
        
        [self addSubview:self.scrollView];
        [self addTitleToLabel];
        
        //添加通知，用于接收停止操作，执行动画
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(stopCalculagraph) name:@"stopCalculagraph" object:nil];
        
    }
    return self;
}

#pragma mark *** Public ***
- (void)increase {
    
    self.recordIncreaseTimes ++;
    [self.scrollView setContentOffset:CGPointMake(0, self.scrollView.bounds.size.height * 2) animated:YES];
   
}

#pragma mark *** Private ***
- (void)stopCalculagraph {
    self.recordIncreaseTimes = 0;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.4 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        
        if (_isten) {
            self.imageNames = [NSMutableArray arrayWithArray:@[@"calculagraph9", @"calculagraph0", @"calculagraph1", @"calculagraph2", @"calculagraph3", @"calculagraph4", @"calculagraph5", @"calculagraph6", @"calculagraph7", @"calculagraph8"]];
        }else {
            self.imageNames = [NSMutableArray arrayWithArray:@[@"calculagraph5", @"calculagraph0", @"calculagraph1", @"calculagraph2", @"calculagraph3", @"calculagraph4"]];
        }
        [self addTitleToLabel];
    });
    
}

- (void)addTitleToLabel {
    
    [_images enumerateObjectsUsingBlock:^(UIImageView *  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        obj.image = [UIImage imageNamed:self.imageNames[idx]];
    }];
}

#pragma mark *** UIScrollViewDelegate ***
- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    
    if (scrollView.contentOffset.y >= scrollView.bounds.size.height * 2) {
        id firstObj = [self.imageNames.firstObject mutableCopy];
        [self.imageNames removeObjectAtIndex:0];
        [self.imageNames addObject:firstObj];
        
    }else if (scrollView.contentOffset.y <= 0) {
        id lastObj = [self.imageNames.lastObject mutableCopy];
        [self.imageNames removeLastObject];
        [self.imageNames insertObject:lastObj atIndex:0];
    }else {
        return;
    }
    
    [self addTitleToLabel];
    scrollView.contentOffset = CGPointMake(0, scrollView.bounds.size.height);
}

#pragma mark *** Getter ***
- (UIScrollView *)scrollView {
    if (!_scrollView) {
        _scrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, self.bounds.size.width, self.bounds.size.height)];
        _scrollView.contentSize = CGSizeMake(_scrollView.bounds.size.width, _scrollView.bounds.size.height * 3);
        _scrollView.contentOffset = CGPointMake(0, _scrollView.bounds.size.height);
        _scrollView.delegate = self;
        _scrollView.userInteractionEnabled = NO;
        _scrollView.showsHorizontalScrollIndicator = NO;
        _scrollView.showsVerticalScrollIndicator = NO;
        _scrollView.pagingEnabled = YES;
    }
    return _scrollView;
}

@end
