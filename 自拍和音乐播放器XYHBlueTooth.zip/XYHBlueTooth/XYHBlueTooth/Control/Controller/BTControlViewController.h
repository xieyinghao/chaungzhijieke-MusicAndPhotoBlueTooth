//
//  ControlViewController.h
//  XYZBluetooth
//
//  Created by 谢英泽 on 2016/11/26.
//  Copyright © 2016年 谢英泽. All rights reserved.
//

#import "BaseViewController.h"

@interface BTControlViewController : BaseViewController

@end
