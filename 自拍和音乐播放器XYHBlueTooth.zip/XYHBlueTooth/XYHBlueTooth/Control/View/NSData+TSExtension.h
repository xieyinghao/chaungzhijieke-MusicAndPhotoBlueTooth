//
//  NSData+TSExtension.h
//  37duc
//
//  Created by Ray on 16/2/24.
//  Copyright © 2016年 37service. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSData (TSExtension)
/** NSData转换成字符串*/
- (NSString *)ConvertToNSString;
@end
