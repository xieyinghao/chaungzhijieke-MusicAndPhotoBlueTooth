//
//  XYZPickerCellView.h
//  XYZPickerView
//
//  Created by xieyingze on 16/8/8.
//  Copyright © 2016年 xieyingze. All rights reserved.
//

#import <UIKit/UIKit.h>

@class XYZPickerCellView;

@protocol XYZPickerCellView <NSObject>

- (void)xyzPickerCellView:(XYZPickerCellView *)pickerView choice:(NSString *)content viewTag:(NSUInteger)tag indexRow:(NSInteger)row;

@end

@interface XYZPickerCellView : UIView<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic, strong)UITableView *tableView;

//所有数据
@property (nonatomic, strong)NSArray *dataLists;
//默认选中
@property (nonatomic, assign)NSInteger defaultSeleted;
//文字颜色
@property (nonatomic, assign)UIColor *tinColor;

@property (nonatomic, weak)id<XYZPickerCellView>delegate;

@end
