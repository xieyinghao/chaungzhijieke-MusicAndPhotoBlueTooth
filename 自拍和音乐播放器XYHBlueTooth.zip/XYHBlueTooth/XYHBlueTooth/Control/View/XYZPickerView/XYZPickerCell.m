//
//  XYZPickerCell.m
//  XYZPickerView
//
//  Created by xieyingze on 16/8/8.
//  Copyright © 2016年 xieyingze. All rights reserved.
//

#import "XYZPickerCell.h"

@implementation XYZPickerCell

- (void)awakeFromNib
{
    
}

+(id)initFromXIB
{
    NSArray* xibs = [[NSBundle mainBundle]loadNibNamed:@"XYZPickerCell" owner:self options:nil];
    
    return xibs[0];
}

@end
