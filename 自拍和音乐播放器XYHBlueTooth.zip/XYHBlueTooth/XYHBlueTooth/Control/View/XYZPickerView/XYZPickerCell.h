//
//  XYZPickerCell.h
//  XYZPickerView
//
//  Created by xieyingze on 16/8/8.
//  Copyright © 2016年 xieyingze. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XYZPickerCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *lbText;

+ (id)initFromXIB;

@end
