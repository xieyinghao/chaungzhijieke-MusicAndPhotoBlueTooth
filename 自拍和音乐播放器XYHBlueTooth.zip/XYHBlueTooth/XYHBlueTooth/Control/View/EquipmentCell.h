//
//  EquipmentCell.h
//  Fibit
//
//  Created by xieyingze on 16/11/24.
//  Copyright © 2016年 ShenZhenHaoHanCompany. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface EquipmentCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *name;
@property (weak, nonatomic) IBOutlet UILabel *textLable;
@property (weak, nonatomic) IBOutlet UIButton *contectButton;
@property (weak, nonatomic) IBOutlet UILabel *macLable;

@end
