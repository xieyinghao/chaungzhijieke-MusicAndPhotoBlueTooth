//
//  SleepResultNotifyView.m
//  XYHBlueTooth
//
//  Created by xieyingze on 16/11/27.
//  Copyright © 2016年 谢英泽. All rights reserved.
//

#import "SleepResultNotifyView.h"

@implementation SleepResultNotifyView

+ (id)initFromXIB
{
    NSArray* xibs = [[NSBundle mainBundle]loadNibNamed:@"SleepResultNotifyView" owner:self options:nil];
    
    return xibs[0];
}
@end
