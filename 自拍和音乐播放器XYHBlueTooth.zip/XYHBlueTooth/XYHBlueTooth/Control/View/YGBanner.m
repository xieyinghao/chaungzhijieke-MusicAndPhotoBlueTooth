//
//  YGBanner.m
//  
//
//  Created by wuyiguang on 16/4/27.
//
//

#import "YGBanner.h"

typedef void(^imageHandle)(NSString *title);

@interface YGBanner () <UIScrollViewDelegate>

// 用来记录block
@property (nonatomic, strong) imageHandle imageHandle;

@end

@implementation YGBanner
{
    UIScrollView *_scrollView;
    UIPageControl *_pageControl;
    NSArray *_imageNames;
    NSTimer *_timer;
    CGSize _size;
}

- (instancetype)initWithFrame:(CGRect)frame imageNames:(NSArray *)names imageHandle:(void (^)(NSString *))handle
{
    if (self = [super initWithFrame:frame]) {
        
        // 记录数据
        _imageNames = names;
        _imageHandle = handle;
        _size = frame.size;
        
        // 创建UIScrollView
        [self createScrollView];
        
        // 创建图片
        [self createImageView];
        
        // 创建UIPageControl
        [self createPageControl];
        
        // 定时器
        [self createTimer];
    }
    return self;
}

// 创建UIScrollView
- (void)createScrollView
{
    _scrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, _size.width, _size.height)];
    _scrollView.showsHorizontalScrollIndicator = NO;
    _scrollView.pagingEnabled = YES;
    _scrollView.delegate = self;
    _scrollView.bounces = NO;
    [self addSubview:_scrollView];
    
    // 设置滚动区域
    _scrollView.contentSize = CGSizeMake(_size.width * _imageNames.count, _size.height);
}

// 创建图片
- (void)createImageView
{
    for (int i = 0; i < _imageNames.count; i++)
    {
        UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(_size.width * i, 0, _size.width, _size.height)];
        
        imageView.image = [UIImage imageNamed:_imageNames[i]];
        
        [_scrollView addSubview:imageView];
        
        
        // 添加手势
        imageView.userInteractionEnabled = YES;
        
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(imageAction)];
        
        [imageView addGestureRecognizer:tap];
    }
}

// 图片点击事件
- (void)imageAction
{
    // 判断是否有实现block
    if (_imageHandle)
    {
        _imageHandle(_imageNames[_pageControl.currentPage]);
    }
}

// 创建UIPageControl
- (void)createPageControl
{
    _pageControl = [[UIPageControl alloc] initWithFrame:CGRectMake(0,0, _size.width, 30)];
    _pageControl.backgroundColor = [[UIColor grayColor] colorWithAlphaComponent:0.5];
    _pageControl.numberOfPages = _imageNames.count;
    _pageControl.enabled = NO;
    [self addSubview:_pageControl];
}

// 创建定时器
- (void)createTimer
{
    _timer = [NSTimer scheduledTimerWithTimeInterval:3.0 target:self selector:@selector(autoTimer) userInfo:nil repeats:YES];
}

// 定时器滑动UIScrollView
- (void)autoTimer
{
    // 设置pageControl的值
    _pageControl.currentPage = (_pageControl.currentPage + 1) % _imageNames.count;
    
    // 设置图片偏移量
    [_scrollView setContentOffset:CGPointMake(_size.width * _pageControl.currentPage, 0) animated:YES];
}

#pragma mark - UIScrollViewDelegate

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    NSInteger index = scrollView.contentOffset.x / _size.width;
    
    _pageControl.currentPage = index;
    
    [self createTimer];
}

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView
{
    [_timer invalidate];
    _timer = nil;
}

@end
