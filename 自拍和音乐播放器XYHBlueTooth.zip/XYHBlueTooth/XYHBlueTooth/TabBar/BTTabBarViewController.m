//
//  BTTabBarViewController.m
//  XYZBluetooth
//
//  Created by 谢英泽 on 2016/11/26.
//  Copyright © 2016年 谢英泽. All rights reserved.
//

#import "BTTabBarViewController.h"
#import "BTHomeViewController.h"
#import "BTChallengeViewController.h"
#import "BTControlViewController.h"
#import "BTMeViewController.h"

@interface BTTabBarViewController ()<UITabBarControllerDelegate>

@end

@implementation BTTabBarViewController

+ (id)instanceFromStoryBoard
{
    UIStoryboard* sb = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    if(sb)
    {
        return [sb instantiateViewControllerWithIdentifier:@"BTTabBarViewControllerID"];
    }else{
        return nil;
    }
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.delegate = self;
    
    [self setupContent];
    
    [self setupStyle];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    [[UIApplication sharedApplication] setStatusBarHidden:NO withAnimation:UIStatusBarAnimationFade];
    self.view.alpha = 1.0f;
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    
    [[UIApplication sharedApplication] setStatusBarHidden:YES withAnimation:UIStatusBarAnimationFade];
    self.view.alpha = 0.f;
}

-(void)setupStyle
{
    self.tabBar.backgroundColor = [UIColor whiteColor];
    self.tabBar.tintColor = kCOLOR_tabBar;
    
    for(UITabBarItem* item in self.tabBar.items)
    {
        switch (item.tag) {
            case 0:
                item.selectedImage = [UIImage imageNamed:@"tabbar_home_selected"];
                break;
            case 1:
                item.selectedImage = [UIImage imageNamed:@"tabbar_control_selected"];
                break;
            case 2:
                item.selectedImage = [UIImage imageNamed:@"tabbar_control_selected"];
                break;
            case 3:
                item.selectedImage = [UIImage imageNamed:@"tabbar_me_selected"];
                break;
        }
    }
}

-(void)setupContent
{
    //设置主页
    UINavigationController *homeNav = self.viewControllers[0];
    if([homeNav isKindOfClass:[UINavigationController class]])
    {
        BTHomeViewController *homeCtrl = [BTHomeViewController new];
        NSArray* array = @[homeCtrl];
        [homeNav setViewControllers:array];
    }
    
    //设置挑战
    UINavigationController *challengeNav = self.viewControllers[1];
    if([challengeNav isKindOfClass:[UINavigationController class]])
    {
        BTChallengeViewController *challengeCtrl = [BTChallengeViewController new];
        NSArray* array = @[challengeCtrl];
        [challengeNav setViewControllers:array];
    }
    
    //设置控制
    UINavigationController *controlNav = self.viewControllers[2];
    if([controlNav isKindOfClass:[UINavigationController class]])
    {
        BTControlViewController *controlCtrl = [BTControlViewController new];
        NSArray* array = @[controlCtrl];
        [controlNav setViewControllers:array];
    }
    
    //设置我的
    UINavigationController* meNav = self.viewControllers[3];
    if([meNav isKindOfClass:[UINavigationController class]])
    {
        BTMeViewController* meCtrl = [BTMeViewController new];
        NSArray* array = @[meCtrl];
        [meNav setViewControllers:array];
    }
}

#pragma mark - tab代理

- (BOOL)tabBarController:(UITabBarController *)tabBarController shouldSelectViewController:(UIViewController *)viewController
{
    int index = 0;
    for(int i=0;i<self.viewControllers.count;i++)
    {
        if(viewController == self.viewControllers[i])
        {
            index = i;
            break;
        }
    }
    return YES;
}

@end
