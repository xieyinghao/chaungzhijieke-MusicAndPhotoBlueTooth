//
//  37duc
//
//  Created by Ray on 16/1/21.
//  Copyright © 2016年 37service. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TSSquareButton : UIButton

@end
