//
//  UIView+HeartBeat.h
//  XYZKitDemo
//
//  Created by 谢英泽 on 2016/11/20.
//  Copyright © 2016年 谢英泽. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (HeartBeat)

- (void)heartBeat:(id)repeatTimes;

- (void)stopHeartBeat;

@end
