//
//  UserDefine.h
//  XYZKitDemo
//
//  Created by 谢英泽 on 2016/11/20.
//  Copyright © 2016年 谢英泽. All rights reserved.
//

#ifndef UserInfoDefine_h
#define UserInfoDefine_h


/**
 用户信息类
 */
#define     kUSER_userId       @"User_Id"

#define kUSER_Name          @"kUSER_Name"
#endif /* UserInfoDefine_h */
