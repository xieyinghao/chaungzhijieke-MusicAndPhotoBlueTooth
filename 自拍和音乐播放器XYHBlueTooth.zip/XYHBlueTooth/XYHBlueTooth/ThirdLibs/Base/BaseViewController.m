//
//  BaseViewController.m
//  MasonryDemo
//
//  Created by 谢英泽 on 2016/11/11.
//  Copyright © 2016年 wtjr. All rights reserved.
//

#import "BaseViewController.h"
#import "UIImage+Color.h"

#define kCOLOR_BaseViewControllerBackground     [UIColor whiteColor]
#define kNav_BackIcon                           @"nav_back"

#define kImage_WithoutData                      @"wt_notData_header1"

@interface BaseViewController ()

@end

@implementation BaseViewController

#pragma mark - *********************生命周期*********************

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self baseConfiguration];
}

#pragma mark - *********************基础配置*********************

- (void)baseConfiguration
{
    //设置默认背景色
    self.view.backgroundColor = kCOLOR_BaseViewControllerBackground;
    //设置导航栏默认的起点为(0,0)
    self.navigationController.navigationBar.translucent = NO;
    //设置状态栏背景色跟内容一致
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent animated:YES];
    //设置导航栏颜色
    [self.navigationController.navigationBar setBackgroundImage:[UIImage imageWithColor:kCOLOR_tabBar] forBarMetrics:UIBarMetricsDefault];
    self.navigationController.navigationBar.barStyle = UIBarStyleBlackOpaque;
    
    //开启系统侧滑
    self.navigationController.interactivePopGestureRecognizer.delegate = (id)self;
    
    [self resetNavBackItemTinColor:kCOLOR_white];
    
    [self setupBackNaviBar];
}

#pragma mark - *********************基础方法*********************

#pragma mark - 跳转

-(void)modal:(UIViewController *)modal from:(UIViewController*)from
{
    from.hidesBottomBarWhenPushed = YES;
    UINavigationController* navi = [[UINavigationController alloc]initWithRootViewController:modal];
    [from presentViewController:navi animated:YES completion:nil];
}

-(void)push:(UIViewController*)push from:(UINavigationController *)from
{
    [push setHidesBottomBarWhenPushed:YES];
    [from pushViewController:push animated:YES];
}

#pragma mark - 设置导航栏返回按钮

-(void)setupBackNaviBar
{
    UIBarButtonItem *backBar = [[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:kNav_BackIcon] style:UIBarButtonItemStylePlain target:self action:@selector(onNaviBack)];
    
    [self.navigationItem setLeftBarButtonItem:backBar];
}

-(void)onNaviBack
{
    [self finishNavi];
}

-(void)finishNavi
{
    if (self.navigationController) {
        if ([self.navigationController.viewControllers firstObject] == self) {
            [self dismissViewControllerAnimated:YES completion:nil];
        }else {
            [self.navigationController popViewControllerAnimated:YES];
        }
    }else {
        [self dismissViewControllerAnimated:YES completion:nil];
    }
}

-(void)hideNaviBack
{
    self.navigationItem.hidesBackButton = YES;
    self.navigationItem.leftBarButtonItem = nil;
    self.navigationItem.backBarButtonItem = nil;
}

- (void)resetNavBackItemTinColor:(UIColor *)color
{
    //设置返回按钮样式(在基类该方法无效)
    self.navigationItem.leftBarButtonItem.tintColor = color;
}

#pragma mark - 跳转到注册登录


#pragma mark - 没有数据提示页面

- (UIView *)withoutDataView
{
    if (!_withoutDataView) {
        //提示背景
        _withoutDataView = [UIView new];
        _withoutDataView.backgroundColor = kCOLOR_white;
        [self.view addSubview:_withoutDataView];
        
        [_withoutDataView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.equalTo(@0);
        }];
        
        //提示图片
        CGFloat scale = [UIScreen mainScreen].scale;
        UIImage *tipImage = [UIImage imageNamed:kImage_WithoutData];
        UIImageView *tipImageView = [[UIImageView alloc] initWithImage:tipImage];
        [_withoutDataView addSubview:tipImageView];
        [tipImageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(_withoutDataView);
            make.size.mas_equalTo(CGSizeMake(50 * scale, 50 * scale));
            make.top.equalTo(_withoutDataView).with.offset(kUI_HEIGHT/4);
        }];
        
        //提示文字
        UILabel *tipLabel = [UILabel new];
        [_withoutDataView addSubview:tipLabel];
        [tipLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(tipImageView.mas_bottom).offset(15);
            make.centerX.equalTo(_withoutDataView);
            make.size.mas_equalTo(CGSizeMake(300, 30));
        }];
        [tipLabel setText:@"暂无记录"];
        [tipLabel setTextColor:kCOLOR_gray];
        [tipLabel setFont:kFONT_system(17)];
        tipLabel.textAlignment = NSTextAlignmentCenter;
        
        _withoutDataView.hidden = YES;
    }
    return _withoutDataView;
}

@end
