//
//  BaseViewController.h
//  MasonryDemo
//
//  Created by 谢英泽 on 2016/11/11.
//  Copyright © 2016年 wtjr. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppHeader.h"

@interface BaseViewController : UIViewController

@property (nonatomic, strong) UIView *withoutDataView;
/**
 跳转
 */
- (void)modal:(UIViewController *)modal from:(UIViewController*)from;

- (void)push:(UIViewController*)push from:(UINavigationController *)from;


/**
 返回按钮相关
 */
- (void)setupBackNaviBar;

- (void)hideNaviBack;

- (void)finishNavi;

- (void)resetNavBackItemTinColor:(UIColor *)color;

@end
