//
//  BaseTableViewCell.m
//  WTGesturePassword
//
//  Created by wtjr on 16/11/11.
//  Copyright © 2016年 wtjr. All rights reserved.
//

#import "BaseTableViewCell.h"
#import "Masonry.h"

@implementation BaseTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    
   
}

- (void)setTableViewCellLineType:(kTableViewCellLineType)tableViewCellLineType
{
    _tableViewCellLineType = tableViewCellLineType;
    
    if (_tableViewCellLineType == kTableViewCellLineTypeNone) {
        return;
    }else if (_tableViewCellLineType == kTableViewCellLineTypeNormal){
        UIView *lineView = [[UIView alloc] init];
        lineView.backgroundColor = [UIColor lightGrayColor];
        [self addSubview:lineView];
        
        [lineView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(@20);
            make.right.bottom.equalTo(@0);
            make.height.equalTo(@0.5);
        }];
    }else{
        UIView *lineView = [[UIView alloc] init];
        lineView.backgroundColor = [UIColor lightGrayColor];
        [self addSubview:lineView];
        
        [lineView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.right.bottom.equalTo(@0);
            make.height.equalTo(@0.5);
        }];
    }
}

@end
