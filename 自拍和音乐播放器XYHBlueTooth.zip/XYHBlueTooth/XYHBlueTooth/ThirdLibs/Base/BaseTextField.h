//
//  BaseTextField.h
//  XYZKitDemo
//
//  Created by 谢英泽 on 2016/11/20.
//  Copyright © 2016年 谢英泽. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseTextField : UITextField

/**
 *  是否有输入
 */
@property (nonatomic, copy) void(^inputBlock)(BOOL haveInput);

@end
