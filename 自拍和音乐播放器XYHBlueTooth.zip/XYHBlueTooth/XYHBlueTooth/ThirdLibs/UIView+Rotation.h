//
//  UIView+Rotation.h
//  CustomTabBarController
//
//  Created by wtjr on 16/11/23.
//  Copyright © 2016年 谢英泽. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef NS_ENUM(NSInteger, kRotateType) {
    
    kRotateTypeX = 0,
    kRotateTypeY,
    kRotateTypeZ,
};

@interface UIView (Rotation)

- (void)rotationView:(kRotateType)rotateType isRepeatTime:(id)repeatTime;

@end
