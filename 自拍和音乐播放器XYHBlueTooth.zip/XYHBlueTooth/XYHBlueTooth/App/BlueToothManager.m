//
//  BlueToothManager.m
//  04-蓝牙
//
//  Created by vera on 16/10/14.
//  Copyright © 2016年 deli. All rights reserved.
//

#import "BlueToothManager.h"
#import "UnityTool.h"
//服务的UUID
#define kServiceUUID @"00000aF0-0000-1000-8000-00805f9b34fb"

@interface BlueToothManager ()<CBCentralManagerDelegate, CBPeripheralDelegate>

//中心角色管理对象
@property (nonatomic, strong) CBCentralManager *centralManager;


/**
 扫描到的外部设备
 */
@property (nonatomic, strong) NSMutableArray *peripheralArray;


/**
 所有的特征
 */
@property (nonatomic, strong) NSMutableArray *characteristicArray;


/**
 连接的外部设备对象
 */
@property (nonatomic, strong) CBPeripheral *peripheral;

@property (nonatomic, assign)BOOL isFirstClick;

@end

@implementation BlueToothManager

+ (instancetype)shareManager
{
    static BlueToothManager *manager = nil;
    
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        manager = [[self alloc] init];
    });
    
    return manager;
}

- (NSMutableArray *)characteristicArray
{
    if (!_characteristicArray)
    {
        _characteristicArray = [NSMutableArray array];
    }
    
    return _characteristicArray;
}

- (NSMutableArray *)peripheralArray
{
    if (!_peripheralArray)
    {
        _peripheralArray = [NSMutableArray array];
    }
    
    return _peripheralArray;
}

/**
 开始扫描
 */
- (void)scan
{
    _isFirstClick = YES;
    //创建中心角色对象，初始化完后代理方法就会触发
    _centralManager = [[CBCentralManager alloc] initWithDelegate:self queue:dispatch_get_main_queue()];
}
// 停止扫描
-(void)stopScan
{
     [_centralManager stopScan];
}
/**
 连接外部设备
 
 @param peripheral <#peripheral description#>
 */
- (void)connect:(CBPeripheral *)peripheral
{
    //连接指定的外部设备对象
//     [UnityTool  setStringValueForConfigurationKey:@"bangdingID" WithValue:peripheral.identifier.UUIDString];
    if ([peripheral.identifier.UUIDString isEqualToString:[UnityTool getStringValueForConfigurationKey:@"bangdingID"]]) {
        
         [self.centralManager connectPeripheral:peripheral options:nil];
         [self.centralManager stopScan];
        NSLog(@"连接成功!!!!");
    }

}

/**
 发送数据
 
 @param data       <#data description#>
 @param uuidString <#uuidString description#>
 */
- (void)writeData:(NSData *)data characteristicUUIDString:(NSString *)uuidString type:(CBCharacteristicWriteType)type
{
    //获取CBCharacteristic
    CBCharacteristic *c = [self characteristicWithUUIDString:uuidString];
   
    if (!c)
    {
        return;
    }
    
    //发送数据
    [self.peripheral writeValue:data forCharacteristic:c type:type];
}


/**
 根据uuidstring获取CBCharacteristic

 @param uuidString <#uuidString description#>

 @return <#return value description#>
 */
- (CBCharacteristic *)characteristicWithUUIDString:(NSString *)uuidString
{
    for (CBCharacteristic *c in self.characteristicArray)
    {
        if ([c.UUID.UUIDString isEqualToString:uuidString])
        {
            return c;
        }
    }
    
    return nil;
}

#pragma mark - CBCentralManagerDelegate

/**
 获取蓝牙状态

 @param central <#central description#>
 */
- (void)centralManagerDidUpdateState:(CBCentralManager *)central
{
    if (central.state == CBManagerStateUnsupported)
    {
        NSLog(@"目前手机不支持蓝牙4.0");
        
        return;
    }
    else if (central.state == CBManagerStatePoweredOff)
    {
        NSLog(@"请先打开蓝牙");
        
        return;
    }
    else if (central.state == CBManagerStatePoweredOn)
    {
        NSLog(@"蓝牙已经打开");
        
        NSUUID *uuid = [[NSUUID alloc] initWithUUIDString:ServicesUUID];
        
        //开始扫描
        /*
         第1个参数：指定扫描外设的UUID,如果传nil表示扫描所有的外部设备
         */
       // [_centralManager scanForPeripheralsWithServices:@[uuid] options:nil];
        [_centralManager scanForPeripheralsWithServices:nil options:nil];
    }
}


/**
 已经扫描到外部设备

 @param central           <#central description#>
 @param peripheral        <#peripheral description#>
 @param advertisementData <#advertisementData description#>
 @param RSSI              <#RSSI description#>
 */
- (void)centralManager:(CBCentralManager *)central didDiscoverPeripheral:(CBPeripheral *)peripheral advertisementData:(NSDictionary<NSString *, id> *)advertisementData RSSI:(NSNumber *)RSSI
{
    //获取到外部设备的名字
    NSString *name = peripheral.name;
    NSLog(@"%@",name);
    
//    //保存扫描的外部设备对象
//    if (![self.peripheralArray containsObject:peripheral])
//    {
//        [self.peripheralArray addObject:peripheral];
//    }
    
    //保存扫描的外部设备对象 ,保存SMART名称的外设
//      [UnityTool  setStringValueForConfigurationKey:@"bangdingID" WithValue:peripheral.identifier.UUIDString];
    if ([peripheral.identifier.UUIDString isEqualToString:[UnityTool getStringValueForConfigurationKey:@"bangdingID"]]) {
        
        //保存扫描的外部设备对象
        if (![self.peripheralArray containsObject:peripheral])
        {
            [self.peripheralArray addObject:peripheral];
        }
    }
    
    //扫描结果的回调
    if (self.peripheralArray.count > 0 && self.blueToothDidScanPeripheralsCallback)
    {
        _blueToothDidScanPeripheralsCallback(self.peripheralArray);
    }
}


/**
 已经连接成功

 @param central    <#central description#>
 @param peripheral <#peripheral description#>
 */
- (void)centralManager:(CBCentralManager *)central didConnectPeripheral:(CBPeripheral *)peripheral
{
    //1.连接的外部设备
    self.peripheral = peripheral;
    
    //2.设置外部设备的代理
    self.peripheral.delegate = self;
    
    //3.扫描外部设备的服务
    [self.peripheral discoverServices:nil];
    //与外设断开连接   重连
      [central connectPeripheral:peripheral options:nil];
}

/**
 扫描到外部设备的服务

 @param peripheral <#peripheral description#>
 @param error      <#error description#>
 */
- (void)peripheral:(CBPeripheral *)peripheral didDiscoverServices:(nullable NSError *)error
{
    //1.获取外部设备所有的服务
    NSArray *servies = peripheral.services;
    
    //2.遍历服务
    for (CBService *service in servies)
    {
        //3.扫描服务中的特征
        [peripheral discoverCharacteristics:nil forService:service];
    }
}


/**
 扫描到服务中的特征

 @param peripheral <#peripheral description#>
 @param service    <#service description#>
 @param error      <#error description#>
 */
- (void)peripheral:(CBPeripheral *)peripheral didDiscoverCharacteristicsForService:(CBService *)service error:(nullable NSError *)error
{
    //1.获取服务中的特征
    NSArray *characteristicsArr = service.characteristics;
    
    //2.遍历特征
    for (CBCharacteristic *c in characteristicsArr)
    {
        if (![self.characteristicArray containsObject:c])
        {
            //3.添加特征
            [self.characteristicArray addObject:c];
             [peripheral setNotifyValue:YES forCharacteristic:c];
        }
    }
}


/**
 发送数据成功

 @param peripheral     <#peripheral description#>
 @param characteristic <#characteristic description#>
 @param error          <#error description#>
 */
- (void)peripheral:(CBPeripheral *)peripheral didWriteValueForCharacteristic:(CBCharacteristic *)characteristic error:(nullable NSError *)error
{
    NSLog(@"向外部设备发送数据，发送成功了%@",characteristic.value);
}

//与外设断开连接   重连
- (void)centralManager:(CBCentralManager *)central didDisconnectPeripheral:(CBPeripheral *)peripheral error:(NSError *)error{
    NSLog(@"与外设备断开连接 %@: %@", [peripheral name], [error localizedDescription]);
    
    [central connectPeripheral:peripheral options:nil];
}
/**
 收到外部设备发来的数据会触发

 @param peripheral     <#peripheral description#>
 @param characteristic <#characteristic description#>
 @param error          <#error description#>
 */
- (void)peripheral:(CBPeripheral *)peripheral didUpdateValueForCharacteristic:(CBCharacteristic *)characteristic error:(nullable NSError *)error
{
    //1.获取外部设备的数据
    NSData *value = characteristic.value;
    
     [peripheral setNotifyValue:YES forCharacteristic:characteristic];
    if ([characteristic.UUID.UUIDString isEqualToString:NotifyUUID])
    {
        
        [peripheral setNotifyValue:YES forCharacteristic:characteristic];
        NSLog(@"通知的data==========%@",characteristic.value);
        
        Byte byte1[3];
        byte1[0] = 0xf5;
        byte1[1] = 0x00;
        byte1[2] = 0x00;//
         NSData *data1 = [NSData dataWithBytes:byte1 length:3];

        if ([characteristic.value isEqualToData:data1]) {
            if (_isFirstClick) {
                [UnityTool setBoolValueForConfigurationKey:@"zipai" WithValue:YES];
                _isFirstClick = NO;
                
                //发送通知
                [[NSNotificationCenter defaultCenter] postNotificationName:@"zipai" object:nil];
                
            }else{
                
                [[NSNotificationCenter defaultCenter] postNotificationName:@"shutterCamera" object:nil];
                 _isFirstClick = YES;
            }
            
        }
        
        Byte *byte = (void *)characteristic.value.bytes;
        
        //command_id
        Byte command_id = byte[0];
        //key
        Byte key = byte[1];
        if (command_id == 0x26 && key == 0x09) {
            
            //发送通知
            [[NSNotificationCenter defaultCenter] postNotificationName:@"steps" object:characteristic.value];

        }
        //音乐播放 <f60102> 上一首  <f60103>下一首  <f60101>暂停与播放
        if (command_id == 0xf6 && key == 0x01) {
            
            [[NSNotificationCenter defaultCenter] postNotificationName:@"musicPlay" object:characteristic.value];
            
        }

    }
    //2.回调
    if (_blueToothDidUpdateValueCallback)
    {
        _blueToothDidUpdateValueCallback(characteristic, value);
    }
}

- (void)sendBasicMassage
{
    
    NSString *uuid = WriteUUID;
    
    /*
     20字节
     
     //数据包格式：
     command_id(1个字节)  key(1个字节)  value(18个字节)
     
     获得设备基本信息 (command_id 为 0x02, key 为 0x01)
     
     */
    Byte byte[2];
    byte[0] = 0x02; //command_id
    byte[1] = 0x01;  //key
    
    NSData *data = [NSData dataWithBytes:byte length:2];
    
    //获得设备基本信息
    [[BlueToothManager shareManager] writeData:data characteristicUUIDString:uuid type:CBCharacteristicWriteWithResponse];
    //设置接收硬件数据的回调
    [[BlueToothManager shareManager] setBlueToothDidUpdateValueCallback:^(CBCharacteristic *characteristic, NSData *value)
     {
         //处理结果
         [self handleValue:value];
     }];
    
}
/**
 处理硬件返回的数据
 
 @param data <#data description#>
 */
- (void)handleValue:(NSData *)data
{
    Byte *byte = (void *)data.bytes;
    
    //command_id
    Byte command_id = byte[0];
    //key
    Byte key = byte[1];
    
    //获得设备基本信息
    if (command_id == 0x02 && key == 0x01)
    {
        //固件版本号
        Byte b[] = {byte[2]};
        NSData *adata = [[NSData alloc] initWithBytes:b length:sizeof(b)];
        NSString *str = [adata ConvertToNSString];
        UInt64 weight = strtoul([str UTF8String], 0, 16);
        
    }

}
- (void)peripheral:(CBPeripheral *)peripheral regNotifyWithCharacteristic:(nonnull CBCharacteristic *)characteristic
{
    // 外设为特征订阅通知
    [peripheral setNotifyValue:YES forCharacteristic:characteristic];
}
- (void)peripheral:(CBPeripheral *)peripheral CancleRegNotifyWithCharacteristic:(nonnull CBCharacteristic *)characteristic
{
    // 外设取消订阅通知
    [peripheral setNotifyValue:NO forCharacteristic:characteristic];
}
//断开连接
- (void)dismissConentedWithPeripheral:(CBPeripheral *)peripheral
{
    // 停止扫描
    [_centralManager stopScan];
    // 断开连接
    [self.centralManager cancelPeripheralConnection:peripheral];
}
@end
