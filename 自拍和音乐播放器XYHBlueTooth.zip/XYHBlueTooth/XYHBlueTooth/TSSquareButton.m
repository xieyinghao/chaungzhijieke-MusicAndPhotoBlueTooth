//
//  37duc
//
//  Created by Ray on 16/1/21.
//  Copyright © 2016年 37service. All rights reserved.
//

#import "TSSquareButton.h"
#import "UIView+TSExtension.h"
@implementation TSSquareButton

- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        self.titleLabel.textAlignment = NSTextAlignmentCenter;
        self.titleLabel.font = [UIFont systemFontOfSize:12.0];
        [self setBackgroundColor:[UIColor whiteColor]];
        [self setTitleColor:[UIColor colorWithRed:55/255.0 green:55/255.0 blue:55/255.0 alpha:1] forState:UIControlStateNormal];
    }
    return self;
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    
    self.imageView.TS_width = self.TS_width * 0.4;
    self.imageView.TS_height = self.imageView.TS_width;
    self.imageView.TS_y = self.TS_height * 0.25;
    self.imageView.TS_centerX = self.TS_width * 0.5;
    
    self.titleLabel.TS_width = self.TS_width;
    self.titleLabel.TS_y = self.imageView.TS_buttom ;
//    self.titleLabel.TS_height = self.TS_height - self.titleLabel.TS_y;
    self.titleLabel.TS_height = 25;
    self.titleLabel.TS_x = 0;
}

@end
