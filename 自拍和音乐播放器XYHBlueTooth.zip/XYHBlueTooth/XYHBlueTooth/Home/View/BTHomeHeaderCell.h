//
//  BTHomeHeaderCell.h
//  XYZBluetooth
//
//  Created by 谢英泽 on 2016/11/27.
//  Copyright © 2016年 谢英泽. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppHeader.h"

@interface BTHomeHeaderCell : UICollectionViewCell

@property (nonatomic, assign) NSInteger stepNumber;

@end
