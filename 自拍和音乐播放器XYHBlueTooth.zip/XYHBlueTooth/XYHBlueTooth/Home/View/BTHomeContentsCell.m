//
//  BTHomeContentsCell.m
//  XYZBluetooth
//
//  Created by 谢英泽 on 2016/11/27.
//  Copyright © 2016年 谢英泽. All rights reserved.
//

#import "BTHomeContentsCell.h"
#import "UIView+Rotation.h"
#import "UIView+HeartBeat.h"
#import "UILabel+Style.h"

@interface BTHomeContentsCell ()

@property (nonatomic, strong) UIImageView *picImageView;

@property (nonatomic, strong) UILabel *contentsLabel;

@property (nonatomic, strong) UILabel *descripeLabel;

@end

@implementation BTHomeContentsCell

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self setBackgroundColor:kCOLOR_white];
        [self initSubView];
    }
    return self;
}

- (void)initSubView
{
    [self addSubview:self.picImageView];
    [self addSubview:self.contentsLabel];
    [self addSubview:self.descripeLabel];
    
    
    __weak typeof (self) weakself = self;
    
    [self.picImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(@20);
        make.width.equalTo(@60);
        make.height.equalTo(@60);
        make.centerX.equalTo(@0);
    }];
    
    [self.contentsLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(weakself.picImageView.mas_bottom).offset(20);
        make.left.equalTo(@20);
        make.right.equalTo(@-20);
        make.height.equalTo(@20);
    }];
    
    [self.descripeLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(weakself.contentsLabel.mas_bottom).offset(5);
        make.left.equalTo(@20);
        make.right.equalTo(@-20);
        make.height.equalTo(@20);
    }];
}

#pragma mark - Setter && Getter


- (void)setHomeCellType:(kHomeContentsCellType)homeCellType
{
    _homeCellType = homeCellType;
    if (homeCellType == kHomeContentsCellTypeStepNumber)
    {
        _picImageView.image = [UIImage imageNamed:@"run_blue"];
        _contentsLabel.text = @"步数统计";
        _descripeLabel.text = @"您今天运动量良好";
//          [_picImageView rotationView:kRotateTypeY isRepeatTime:@999];
        NSMutableArray *imagesArray = [[NSMutableArray alloc] init];
        for(int i=1;i<=6;i++)
        {
            UIImage *image = [UIImage imageNamed:[NSString stringWithFormat:@"跑步-%d.png",i]];
            [imagesArray addObject:image];
        }
        _picImageView.animationImages = imagesArray;
        // 设置播放周期时间
         _picImageView.animationDuration = 0.9;
        // 设置播放次数
         _picImageView.animationRepeatCount =2;
        // 播放动画
        [ _picImageView startAnimating];
    }
    else if (homeCellType == kHomeContentsCellTypeSleepStatus)
    {
        _picImageView.image = [UIImage imageNamed:@"sleep_blue"];
        _contentsLabel.text = @"睡眠状态";
        _descripeLabel.text = @"您昨晚睡眠情况良好";
         [_picImageView heartBeat:@999];
//        [_picImageView.layer layerPopClassics];
    }
    else if (homeCellType == kHomeContentsCellTypeBloodPressure)
    {
        _picImageView.image = [UIImage imageNamed:@"bloodPressure_lightRed"];
        _contentsLabel.text = @"血压测量";
        _descripeLabel.text = @"您今天还没记录血压";
        [_picImageView stopHeartBeat];
        [_picImageView rotationView:kRotateTypeY isRepeatTime:@999];
    }
    else if (homeCellType == kHomeContentsCellTypeHeartRate)
    {
        _picImageView.image = [UIImage imageNamed:@"ratre_lightRed"];
        _contentsLabel.text = @"实时心率";
        _descripeLabel.text = @"您今天的心率良好";
        [_picImageView heartBeat:@999];
    }
}

- (UIImageView *)picImageView
{
    if (!_picImageView) {
        _picImageView = [UIImageView new];
        _picImageView.image = [UIImage imageNamed:@"run_blue"];
        [_picImageView setContentMode:UIViewContentModeScaleToFill];
    }
    return _picImageView;
}

- (UILabel *)contentsLabel
{
    if (!_contentsLabel) {
        _contentsLabel = [UILabel new];
        [_contentsLabel setLabelStyle:@"步数统计" textColor:KCOLOR_font_normal textFont:kFONT_system(16.f) texrAlignment:NSTextAlignmentCenter];
    }
    return _contentsLabel;
}

- (UILabel *)descripeLabel
{
    if (!_descripeLabel) {
        _descripeLabel = [UILabel new];
        [_descripeLabel setLabelStyle:@"您今天运动量良好" textColor:KCOLOR_font_light textFont:kFONT_system(12.f) texrAlignment:NSTextAlignmentCenter];
    }
    return _descripeLabel;
}

@end

