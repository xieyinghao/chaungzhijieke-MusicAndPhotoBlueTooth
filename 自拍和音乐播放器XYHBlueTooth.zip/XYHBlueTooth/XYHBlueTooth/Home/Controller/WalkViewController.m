//
//  WalkViewController.m
//  XYHBlueTooth
//
//  Created by xieyingze on 16/11/28.
//  Copyright © 2016年 谢英泽. All rights reserved.
//
#define ScreenW [UIScreen mainScreen].bounds.size.width
#define ScreenH [UIScreen mainScreen].bounds.size.height
#import "WalkViewController.h"
#import "ZFChart.h"
#import "GFCalendar.h"//日历 
@interface WalkViewController ()
@property(nonatomic,strong)UIView *GFCalendarView;
@end

@implementation WalkViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"步数记录";
    self.view.backgroundColor = [UIColor whiteColor];
    [self showBarChart];
    [self initUI];
}
#pragma mark - *********************基础配置*********************
//初始化日历
-(void)initUI{
    
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"日历"] style:UIBarButtonItemStyleDone target:self action:@selector(showGFCalendar)];//显示日历
    
    self.GFCalendarView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH,ScreenH)];
    self.GFCalendarView.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:self.GFCalendarView];
    self.GFCalendarView.hidden = YES;
}
//初始化步行柱形图
- (void)showBarChart{
    ZFBarChart * barChart = [[ZFBarChart alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT - 64)];
    barChart.title = @"小明11月份步行记录";
//    barChart.xLineValueArray = [NSMutableArray arrayWithObjects:@"800", @"255", @"308", @"273", @"236", @"267",@"280", @"255", @"308", @"273", @"236", @"267",@"280", @"255", @"308", @"273", @"236", @"267", nil];
      barChart.xLineValueArray = [NSMutableArray arrayWithObjects:self.steps, nil];
    barChart.xLineTitleArray = [NSMutableArray arrayWithObjects:@"1", @"2", @"3", @"4", @"5", @"6",  @"7", @"8",@"9", @"10",@"11", @"12",@"13", @"14",@"15", @"16",@"17", @"18",@"19", @"20",@"21", @"22",@"23",@"24", @"25",@"26",@"27", @"28",@"29",@"30", @"31",nil];
    barChart.yLineMaxValue = 5000;
    barChart.yLineSectionCount = 10;
    [self.view addSubview:barChart];
    [barChart strokePath];
}
#pragma mark - *********************点击事件*********************
//rightBarButtonItem 触发事件 
-(void)showGFCalendar
{
    self.view.backgroundColor = [[UIColor grayColor]colorWithAlphaComponent:0.5];
     self.GFCalendarView.hidden = NO;
    CGFloat width = self.view.bounds.size.width - 20.0;
    CGPoint origin = CGPointMake(10.0, 64.0 + 70.0);
    
    GFCalendarView *calendar = [[GFCalendarView alloc] initWithFrameOrigin:origin width:width];
    
    // 点击某一天的回调
    calendar.didSelectDayHandler = ^(NSInteger year, NSInteger month, NSInteger day) {
        
        self.GFCalendarView.hidden = YES;
        self.view.backgroundColor = [UIColor whiteColor];
        self.title = [NSString stringWithFormat:@"%ld-%ld-%ld",year,month,day];
    };
    
    [ self.GFCalendarView addSubview:calendar];
}

@end
