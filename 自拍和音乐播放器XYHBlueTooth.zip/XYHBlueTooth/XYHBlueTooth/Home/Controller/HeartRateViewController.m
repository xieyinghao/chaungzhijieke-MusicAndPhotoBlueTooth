//
//  HeartRateViewController.m
//  XYHBlueTooth
//
//  Created by xieyingze on 16/11/28.
//  Copyright © 2016年 谢英泽. All rights reserved.
//
#define ScreenW [UIScreen mainScreen].bounds.size.width
#define ScreenH [UIScreen mainScreen].bounds.size.height
#import "HeartRateViewController.h"
#import "NSData+TSExtension.h"
#import "BTPercentView.h"
#import "UnityTool.h"
@interface HeartRateViewController ()

@property (nonatomic, strong) UIButton *startButton;
@property (nonatomic, strong) UIButton *pauseButton;
@property(nonatomic,strong)CBPeripheral *peripheral;
@property(nonatomic,strong)CBCharacteristic *characteristic;
@property (nonatomic, strong) BTPercentView *percentView;
@end
static NSString *ServicesUUID   = @"FFF0";// heart 服务UUID
static NSString *NotifyUUID = @"FFF1";// 通知 通知UUID
static NSString *WriteUUID   = @"FFF2";//写    服务UUID
@implementation HeartRateViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"心率测量";
    self.view.backgroundColor = [UIColor whiteColor];
    //去除导航栏下滑线
    [self.navigationController.navigationBar setShadowImage:[UIImage new]];
    //设置颜色
    self.view.backgroundColor = [UIColor colorWithRed:0/255.0 green:164/255.0 blue:197/255.0 alpha:1];
    [self.view addSubview:self.startButton];
    [self.view addSubview:self.pauseButton];
     [self.view addSubview:self.percentView];

}
- (void)startHeartBaet:(UIButton *)sender
{
    theManager = [[CBCentralManager alloc]initWithDelegate:self queue:nil];
   
}
#pragma mark - Getter&&Setter

- (BTPercentView *)percentView
{
    if (!_percentView) {
        
        CGFloat percentViewH = 160;
        
        _percentView = [[BTPercentView alloc] initWithFrame:CGRectMake((ScreenW - percentViewH)/2, 30, percentViewH, percentViewH) andPercent:0.5 andColor:[UIColor redColor]];
        [_percentView reloadViewWithPercent:0];
    }
    return _percentView;
}

#pragma mark - getters

- (UIButton *)startButton
{
    if (!_startButton) {
        self.startButton = [[UIButton alloc] initWithFrame:CGRectMake(50, ScreenH-250, ScreenW-100, 40)];
        [_startButton setTitle:@"开始测量心率" forState:UIControlStateNormal];
        [_startButton setTitleColor:[UIColor colorWithRed:0/255.0 green:164/255.0 blue:197/255.0 alpha:1] forState:UIControlStateNormal];
        _startButton.layer.cornerRadius = 5;
        _startButton.layer.masksToBounds = YES;
        [_startButton addTarget:self action:@selector(startHeartBaet:) forControlEvents:UIControlEventTouchUpInside];
        [_startButton setBackgroundColor:[UIColor whiteColor]];
    }
    
    return _startButton;
}
#pragma mark -蓝牙配置和操作
//-(void)startHeartBaet:(UIButton)btn
//{
//    theManager = [[CBCentralManager alloc]initWithDelegate:self queue:nil];
//    
//}
#pragma mark -当前蓝牙主设备状态
- (void)centralManagerDidUpdateState:(CBCentralManager *)central{
    if (central.state==CBCentralManagerStatePoweredOn) {
        [central scanForPeripheralsWithServices:nil options:nil];
        
    }else
    {
        
        switch (central.state) {
            case CBCentralManagerStateUnknown:
                NSLog(@">>>CBCentralManagerStateUnknown");
                break;
            case CBCentralManagerStateResetting:
                NSLog(@">>>CBCentralManagerStateResetting");
                break;
            case CBCentralManagerStateUnsupported:
                NSLog(@">>>CBCentralManagerStateUnsupported");
                break;
            case CBCentralManagerStateUnauthorized:
                NSLog(@">>>CBCentralManagerStateUnauthorized");
                break;
            case CBCentralManagerStatePoweredOff:
                NSLog(@">>>CBCentralManagerStatePoweredOff");
                break;
                
            default:
                break;
        }
    }
    
    
    
}
//与外设断开连接   重连
- (void)centralManager:(CBCentralManager *)central didDisconnectPeripheral:(CBPeripheral *)peripheral error:(NSError *)error{
    NSLog(@"与外设备断开连接 %@: %@", [peripheral name], [error localizedDescription]);
    
    [central connectPeripheral:peripheral options:nil];
}
//扫描到设备会进入方法
- (void)centralManager:(CBCentralManager *)central didDiscoverPeripheral:(CBPeripheral *)peripheral advertisementData:(NSDictionary *)advertisementData RSSI:(NSNumber *)RSSI{
    NSLog(@"扫描连接外设：%@ %@",peripheral.name,RSSI);
    [central connectPeripheral:peripheral options:nil];
    NSLog(@"peripheral:%@============advertisementData:%@==============RSSI:%@",peripheral.identifier,advertisementData,RSSI);
    //    if ([peripheral.name hasSuffix:@"MI"]) {
    //        thePerpher = peripheral;
    //        [central stopScan];
    //        [central connectPeripheral:peripheral options:nil];
    //        self.title = @"发现小米手环，开始连接...";
    //        self.resultTextV.text = [NSString stringWithFormat:@"发现手环：%@\n名称：%@\n",peripheral.identifier.UUIDString,peripheral.name];
    //    }
    
    if ([peripheral.identifier.UUIDString isEqualToString:[UnityTool getStringValueForConfigurationKey:@"bangdingID"]]) {
        thePerpher = peripheral;
        [central stopScan];
        [central connectPeripheral:peripheral options:nil];
        self.title = @"发现小米手环，开始连接...";
        
    }
}

//连接到Peripherals-成功
- (void)centralManager:(CBCentralManager *)central didConnectPeripheral:(CBPeripheral *)peripheral
{
    self.title = @"连接成功!";
    NSLog(@"连接外设成功！%@",peripheral.name);
    self.peripheral = peripheral;
    [peripheral setDelegate:self];
    [peripheral discoverServices:nil];
    //    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
    //
    //         [self.navigationController popViewControllerAnimated:YES];
    //    });
    
    
}

//扫描到服务
-(void)peripheral:(CBPeripheral *)peripheral didDiscoverServices:(NSError *)error{
    if (error)
    {
        NSLog(@"扫描外设服务出错：%@-> %@", peripheral.name, [error localizedDescription]);
        self.title = @"find services error.";
        return;
    }
    NSLog(@"扫描到外设服务：%@ -> %@",peripheral.name,peripheral.services);
    for (CBService *service in peripheral.services) {
        if ([service.UUID.UUIDString isEqualToString:ServicesUUID]) {
            
            [peripheral discoverCharacteristics:nil forService:service];
            NSLog(@"开始扫描外设服务的特征 %@...",peripheral.name);
        }
    }
    
    
}
//扫描到特征
- (void)peripheral:(CBPeripheral *)peripheral didDiscoverCharacteristicsForService:(CBService *)service error:(NSError *)error{
    if (error)
    {
        NSLog(@"扫描外设的特征失败！%@->%@-> %@",peripheral.name,service.UUID, [error localizedDescription]);
        self.title = @"find characteristics error.";
        return;
    }
    
    NSLog(@"扫描到外设服务特征有：%@->%@->%@",peripheral.name,service.UUID,service.characteristics);
    
    //获取Characteristic的值
    for (CBCharacteristic *characteristic in service.characteristics){
        {
            self.characteristic = characteristic;
            
            [peripheral setNotifyValue:YES forCharacteristic:characteristic];
            [peripheral readValueForCharacteristic:characteristic];
            if ([characteristic.UUID.UUIDString isEqualToString:NotifyUUID])
            {
                
                [peripheral setNotifyValue:YES forCharacteristic:characteristic];
            }
            
            //读取时间
            else if ([characteristic.UUID.UUIDString isEqualToString:WriteUUID])
            {
         
                
                // 读取心率数据  93050000000001 开    93050000000000 关    返回的14.15，16是心率数据   99开头是过程测试
//                <99060000 0000008e 00000000 00000000 00000000>  为过程测试一个数据，9为一个字节，如：08e ===142心率
                Byte byteHeartlv[7];
                byteHeartlv[0] = 0x93;
                byteHeartlv[1] = 0x05;
                byteHeartlv[3] = 0x00;
                byteHeartlv[4] = 0x00;
                byteHeartlv[5] = 0x00;
                byteHeartlv[6] = 0x01;
                NSData *dataHeartlv = [NSData dataWithBytes:byteHeartlv length:7];
                [peripheral writeValue:dataHeartlv forCharacteristic:characteristic type:CBCharacteristicWriteWithResponse];
                
                
            }
        }
    }
    
}
- (void)peripheral:(CBPeripheral *)peripheral didWriteValueForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error {
    
    if (error) {
        
        NSLog(@"Error writing characteristic value: %@",
              
              [error localizedDescription]);
        
    }
    
    
    
}
#pragma mark 设备信息处理
//扫描到具体的值
- (void)peripheral:(CBPeripheral *)peripheral didUpdateValueForCharacteristic:(CBCharacteristic *)characteristic error:(nullable NSError *)error
{
    if (error) {
        NSLog(@"扫描外设的特征失败！%@-> %@",peripheral.name, [error localizedDescription]);
        self.title = @"find value error.";
        return;
    }
    NSLog(@"==characteristic.UUID.UUIDString：%@===characteristic.value：%@",characteristic.UUID.UUIDString,characteristic.value);
    
    if ([characteristic.UUID.UUIDString isEqualToString:@"FFF1"]) {
        
        NSData *data = characteristic.value;
        NSString *value = [NSString stringWithFormat:@"%@",characteristic.value];
        NSLog(@"Value - %@----%@",value,data);
        if (data) {
            Byte *byte = (Byte *)[data bytes];
            Byte b[] = {byte[5],byte[6],byte[7]};
            NSData *adata = [[NSData alloc] initWithBytes:b length:sizeof(b)];
            NSString *str = [adata ConvertToNSString];
            UInt64 weight = strtoul([str UTF8String], 0, 16);
            self.title = [NSString stringWithFormat:@"本次测试心率：%ld",weight]; 
              [self.percentView reloadViewWithPercent:(weight/10)];
        }
        
        
    }
}

@end
