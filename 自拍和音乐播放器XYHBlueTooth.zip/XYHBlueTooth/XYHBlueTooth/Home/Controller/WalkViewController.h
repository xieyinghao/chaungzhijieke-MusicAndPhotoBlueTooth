//
//  WalkViewController.h
//  XYHBlueTooth
//
//  Created by xieyingze on 16/11/28.
//  Copyright © 2016年 谢英泽. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WalkViewController : UIViewController
@property(nonatomic,strong)NSString *steps;
@end
