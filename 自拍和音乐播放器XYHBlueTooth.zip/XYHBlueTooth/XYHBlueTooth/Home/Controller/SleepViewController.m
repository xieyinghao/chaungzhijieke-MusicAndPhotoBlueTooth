//
//  SleepViewController.m
//  XYHBlueTooth
//
//  Created by xieyingze on 16/11/28.
//  Copyright © 2016年 谢英泽. All rights reserved.
//
#define ScreenW [UIScreen mainScreen].bounds.size.width
#define ScreenH [UIScreen mainScreen].bounds.size.height
#import "SleepViewController.h"
#import "WSLineChartView.h"
@interface SleepViewController ()

@end

@implementation SleepViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"睡眠记录";
    self.view.backgroundColor = [UIColor whiteColor];
    
    NSMutableArray *xArray = [NSMutableArray array];
    NSMutableArray *yArray = [NSMutableArray array];
    for (NSInteger i = 0; i < 50; i++) {
        
        [xArray addObject:[NSString stringWithFormat:@"%.1f",3+0.1*i]];
        [yArray addObject:[NSString stringWithFormat:@"%.2lf",20.0+arc4random_uniform(10)]];
        
    }
    
    
    WSLineChartView *wsLine = [[WSLineChartView alloc]initWithFrame:CGRectMake(0,0, self.view.frame.size.width, ScreenH-200) xTitleArray:xArray yValueArray:yArray yMax:24 yMin:0];
    wsLine.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:wsLine];

}



@end
