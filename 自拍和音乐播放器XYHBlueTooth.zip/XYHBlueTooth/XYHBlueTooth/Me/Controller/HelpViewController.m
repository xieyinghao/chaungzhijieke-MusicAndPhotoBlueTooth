//
//  HelpViewController.m
//  XYHBlueTooth
//
//  Created by xieyingze on 16/12/2.
//  Copyright © 2016年 谢英泽. All rights reserved.
//
#define ScreenW [UIScreen mainScreen].bounds.size.width
#define ScreenH [UIScreen mainScreen].bounds.size.height
#import "HelpViewController.h"
#import "YGBanner.h"
@interface HelpViewController ()

@end

@implementation HelpViewController

- (void)viewDidLoad {
    [super viewDidLoad];
   
    self.title = @"使用帮助";
    self.view.backgroundColor = [UIColor whiteColor];
    NSArray *imageNames = @[@"help_index_1", @"help_index_2", @"help_index_3", @"help_index_4",@"help_index_5"];
    
    YGBanner *banner = [[YGBanner alloc] initWithFrame:CGRectMake(0, 0, ScreenW, ScreenH) imageNames:imageNames imageHandle:^(NSString *title) {
        
        
    }];
    
    [self.view addSubview:banner];
}


@end
