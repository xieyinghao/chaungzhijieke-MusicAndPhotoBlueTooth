//
//  SetUpViewController.h
//  Fibit
//
//  Created by xieyingze on 16/11/23.
//  Copyright © 2016年 ShenZhenHaoHanCompany. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SetUpViewController : UIViewController

@end
