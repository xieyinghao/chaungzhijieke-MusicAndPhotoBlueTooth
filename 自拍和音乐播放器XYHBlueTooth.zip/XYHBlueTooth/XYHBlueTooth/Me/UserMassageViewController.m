//
//  UserMassageViewController.m
//  Fibit
//
//  Created by xieyingze on 16/11/23.
//  Copyright © 2016年 ShenZhenHaoHanCompany. All rights reserved.
//
#define ScreenW [UIScreen mainScreen].bounds.size.width
#define ScreenH [UIScreen mainScreen].bounds.size.height
#import "UserMassageViewController.h"
#import "UserNameView.h"
#import "XYZPickerView.h"
#import "UnityTool.h"
#import "UIView+Shake.h"
#import "UIView+HeartBeat.h"
#import "SSPopup.h"
@interface UserMassageViewController ()<UITableViewDelegate,UITableViewDataSource,UIImagePickerControllerDelegate,UITextFieldDelegate,XYZPickerViewDelegate,UITextFieldDelegate>
//* 用户头像按钮
@property (weak, nonatomic)  UIButton *userImageButton;
@property(nonatomic,strong)UILabel *idLable;
@property(nonatomic,strong)UILabel *numberLable1;//昵称
@property(nonatomic,strong)UILabel *numberLable2;//性别
@property(nonatomic,strong)UILabel *numberLable3;//出生年月
@property(nonatomic,strong)UILabel *numberLable4;//身高
@property(nonatomic,strong)UILabel *numberLable5;//体重
@property(nonatomic,strong)UILabel *numberLable6;//步距
@property(nonatomic,strong)UILabel *numberLable7;//运动步距
@property(nonatomic,strong)UserNameView *addView;
@property (nonatomic, assign)XYZPickerType pickerType;
@property(nonatomic,strong)XYZPickerView *pickerView;
@end

@implementation UserMassageViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = @"用户信息";
    [self initUI];
 
}
-(void)initUI
{
    
    UIScrollView *mainScrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, 0, ScreenW, ScreenH)];
    // 显示和隐藏垂直(上下)滑块
    mainScrollView.backgroundColor = [UIColor whiteColor];
    mainScrollView.showsVerticalScrollIndicator = NO;
    // 滚动区域
    mainScrollView.contentSize = CGSizeMake(0,600);
    [self.view addSubview:mainScrollView];
    
    //背景图片
    UIView *bgView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenW, 180)];
    bgView.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"33"]];
    [mainScrollView addSubview:bgView];
    
    UIButton *avatarBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    _userImageButton = avatarBtn;
    avatarBtn.frame = CGRectMake(ScreenW*0.5-40,50 , 80, 80);
    [avatarBtn setImage:[UIImage imageNamed:@"头像大"] forState:UIControlStateNormal];
    // 给view设置圆角
    // 设置圆角
    avatarBtn.layer.cornerRadius = 40.0;
    
    // 允许切圆
    avatarBtn.layer.masksToBounds = YES;
    [avatarBtn setImage:[UIImage imageNamed:@"头像大"] forState:UIControlStateNormal];
    [avatarBtn addTarget:self action:@selector(takePictureClick:) forControlEvents:UIControlEventTouchUpInside];
    [bgView addSubview:avatarBtn];
    
    self.idLable = [[UILabel alloc]initWithFrame:CGRectMake(0, 130, ScreenW, 20)];
    self.idLable.textAlignment = NSTextAlignmentCenter;
    self.idLable.text = [UnityTool  getStringValueForConfigurationKey:kUSER_Name];
    [ self.idLable heartBeat:@9999999999999999];
    //抖动效果
//    [self.idLable shakeWithOptions:SCShakeOptionsDirectionHorizontal | SCShakeOptionsForceInterpolationNone | SCShakeOptionsAtEndContinue force:0.1 duration:10 iterationDuration:0.3 completionHandler:nil];
    self.idLable.textColor = [UIColor grayColor];
    self.idLable.font = [UIFont systemFontOfSize:12];
    [bgView addSubview:self.idLable];
    
    UIView *line1 = [[UIView alloc]initWithFrame:CGRectMake(20, 180, ScreenW-40, 0.5)];
    line1.backgroundColor = [[UIColor grayColor]colorWithAlphaComponent:0.3];
    [mainScrollView addSubview:line1];
    //昵称
    UIButton *btn1 = [[UIButton alloc]initWithFrame:CGRectMake(0, 180.5, ScreenW, 44)];
    [btn1 addTarget:self action:@selector(editName) forControlEvents:UIControlEventTouchUpInside];
    [mainScrollView addSubview:btn1];
    
    UILabel *titleLable1 = [[UILabel alloc]initWithFrame:CGRectMake(20, 0, 100, 44)];
    titleLable1.text = @"昵称";
    titleLable1.font = [UIFont systemFontOfSize:15];
    titleLable1.textColor = [UIColor colorWithRed:51/255.0 green:51/255.0 blue:51/255.0 alpha:1];
    [btn1 addSubview:titleLable1];
    
    self.numberLable1 = [[UILabel alloc]initWithFrame:CGRectMake(ScreenW-140, 0, 100, 44)];
    self.numberLable1.text = [UnityTool getStringValueForConfigurationKey:kUSER_Name];
    self.numberLable1.textAlignment = NSTextAlignmentRight;
    self.numberLable1.font = [UIFont systemFontOfSize:15];
    self.numberLable1.textColor = [UIColor colorWithRed:51/255.0 green:51/255.0 blue:51/255.0 alpha:0.5];
    [btn1 addSubview:self.numberLable1];
    
    UIImageView *image1 = [[UIImageView alloc]initWithFrame:CGRectMake(ScreenW-35, 17, 10, 10)];
    image1.image = [UIImage imageNamed:@"右点击"];
    [btn1 addSubview:image1];
    //性别
    UIView *line2 = [[UIView alloc]initWithFrame:CGRectMake(20, 224.5, ScreenW-40, 0.5)];
    line2.backgroundColor = [[UIColor grayColor]colorWithAlphaComponent:0.3];
    [mainScrollView addSubview:line2];
    
    UIButton *btn2 = [[UIButton alloc]initWithFrame:CGRectMake(0, 225, ScreenW, 44)];
    [btn2 addTarget:self action:@selector(edtSex) forControlEvents:UIControlEventTouchUpInside];
    [mainScrollView addSubview:btn2];
    
    UILabel *titleLable2 = [[UILabel alloc]initWithFrame:CGRectMake(20, 0, 100, 44)];
    titleLable2.text = @"性别";
    titleLable2.font = [UIFont systemFontOfSize:15];
    titleLable2.textColor = [UIColor colorWithRed:51/255.0 green:51/255.0 blue:51/255.0 alpha:1];
    [btn2 addSubview:titleLable2];
    
    self.numberLable2 = [[UILabel alloc]initWithFrame:CGRectMake(ScreenW-140, 0, 100, 44)];
    self.numberLable2.text = [UnityTool getStringValueForConfigurationKey:@"sex"];
    self.numberLable2.textAlignment = NSTextAlignmentRight;
    self.numberLable2.font = [UIFont systemFontOfSize:15];
    self.numberLable2.textColor = [UIColor colorWithRed:51/255.0 green:51/255.0 blue:51/255.0 alpha:0.5];
    [btn2 addSubview:self.numberLable2];
    
    UIImageView *image2 = [[UIImageView alloc]initWithFrame:CGRectMake(ScreenW-35, 17, 10, 10)];
    image2.image = [UIImage imageNamed:@"右点击"];
    [btn2 addSubview:image2];
    
    //出生年月
    UIView *line3 = [[UIView alloc]initWithFrame:CGRectMake(20, 269.5, ScreenW-40, 0.5)];
    line3.backgroundColor = [[UIColor grayColor]colorWithAlphaComponent:0.3];
    [mainScrollView addSubview:line3];
    
    UIButton *btn3 = [[UIButton alloc]initWithFrame:CGRectMake(0, 270, ScreenW, 44)];
    [mainScrollView addSubview:btn3];
    
    UILabel *titleLable3 = [[UILabel alloc]initWithFrame:CGRectMake(20, 0, 100, 44)];
    titleLable3.text = @"出生年月";
    titleLable3.font = [UIFont systemFontOfSize:15];
    titleLable3.textColor = [UIColor colorWithRed:51/255.0 green:51/255.0 blue:51/255.0 alpha:1];
    [btn3 addSubview:titleLable3];
    
    self.numberLable3 = [[UILabel alloc]initWithFrame:CGRectMake(ScreenW-140, 0, 100, 44)];
    self.numberLable3.text = [UnityTool getStringValueForConfigurationKey:@"born"];
    self.numberLable3.textAlignment = NSTextAlignmentRight;
    self.numberLable3.font = [UIFont systemFontOfSize:15];
    self.numberLable3.textColor = [UIColor colorWithRed:51/255.0 green:51/255.0 blue:51/255.0 alpha:0.5];
    [btn3 addSubview:self.numberLable3];
    [btn3 addTarget:self action:@selector(editBorn) forControlEvents:UIControlEventTouchUpInside];
    
    UIImageView *image3 = [[UIImageView alloc]initWithFrame:CGRectMake(ScreenW-35, 17, 10, 10)];
    image3.image = [UIImage imageNamed:@"右点击"];
    [btn3 addSubview:image3];
    
    //身高
    UIView *line4 = [[UIView alloc]initWithFrame:CGRectMake(20, 314, ScreenW-40, 0.5)];
    line4.backgroundColor = [[UIColor grayColor]colorWithAlphaComponent:0.3];
    [mainScrollView addSubview:line4];
    
    UIButton *btn4 = [[UIButton alloc]initWithFrame:CGRectMake(0, 314.5, ScreenW, 44)];
    [btn4 addTarget:self action:@selector(editHeight) forControlEvents:UIControlEventTouchUpInside];
    [mainScrollView addSubview:btn4];
    
    UILabel *titleLable4 = [[UILabel alloc]initWithFrame:CGRectMake(20, 0, 100, 44)];
    titleLable4.text = @"身高";
    titleLable4.font = [UIFont systemFontOfSize:15];
    titleLable4.textColor = [UIColor colorWithRed:51/255.0 green:51/255.0 blue:51/255.0 alpha:1];
    [btn4 addSubview:titleLable4];
    
    self.numberLable4 = [[UILabel alloc]initWithFrame:CGRectMake(ScreenW-140, 0, 100, 44)];
    self.numberLable4.text = [UnityTool getStringValueForConfigurationKey:@"height"];
    self.numberLable4.textAlignment = NSTextAlignmentRight;
    self.numberLable4.font = [UIFont systemFontOfSize:15];
    self.numberLable4.textColor = [UIColor colorWithRed:51/255.0 green:51/255.0 blue:51/255.0 alpha:0.5];
    [btn4 addSubview:self.numberLable4];
    
    UIImageView *image4 = [[UIImageView alloc]initWithFrame:CGRectMake(ScreenW-35, 17, 10, 10)];
    image4.image = [UIImage imageNamed:@"右点击"];
    [btn4 addSubview:image4];
    
    //体重
    UIView *line5 = [[UIView alloc]initWithFrame:CGRectMake(20, 358.5, ScreenW-40, 0.5)];
    line5.backgroundColor = [[UIColor grayColor]colorWithAlphaComponent:0.3];
    [mainScrollView addSubview:line5];
    
    UIButton *btn5 = [[UIButton alloc]initWithFrame:CGRectMake(0, 359, ScreenW, 44)];
    [btn5 addTarget:self action:@selector(editWeight) forControlEvents:UIControlEventTouchUpInside];
    [mainScrollView addSubview:btn5];
    
    UILabel *titleLable5 = [[UILabel alloc]initWithFrame:CGRectMake(20, 0, 100, 44)];
    titleLable5.text = @"体重";
    titleLable5.font = [UIFont systemFontOfSize:15];
    titleLable5.textColor = [UIColor colorWithRed:51/255.0 green:51/255.0 blue:51/255.0 alpha:1];
    [btn5 addSubview:titleLable5];
    
    self.numberLable5 = [[UILabel alloc]initWithFrame:CGRectMake(ScreenW-140, 0, 100, 44)];
    self.numberLable5.text = [UnityTool getStringValueForConfigurationKey:@"Weight"];
    self.numberLable5.textAlignment = NSTextAlignmentRight;
    self.numberLable5.font = [UIFont systemFontOfSize:15];
    self.numberLable5.textColor = [UIColor colorWithRed:51/255.0 green:51/255.0 blue:51/255.0 alpha:0.5];
    [btn5 addSubview:self.numberLable5];
    
    UIImageView *image5 = [[UIImageView alloc]initWithFrame:CGRectMake(ScreenW-35, 17, 10, 10)];
    image5.image = [UIImage imageNamed:@"右点击"];
    [btn5 addSubview:image5];
    
    //步距
    UIView *line6 = [[UIView alloc]initWithFrame:CGRectMake(20, 403, ScreenW-40, 0.5)];
    line6.backgroundColor = [[UIColor grayColor]colorWithAlphaComponent:0.3];
    [mainScrollView addSubview:line6];
    
    UIButton *btn6 = [[UIButton alloc]initWithFrame:CGRectMake(0, 403.5, ScreenW, 44)];
    [btn6 addTarget:self action:@selector(editdistance) forControlEvents:UIControlEventTouchUpInside];
    [mainScrollView addSubview:btn6];
    
    UILabel *titleLable6 = [[UILabel alloc]initWithFrame:CGRectMake(20, 0, 100, 44)];
    titleLable6.text = @"步距";
    titleLable6.font = [UIFont systemFontOfSize:15];
    titleLable6.textColor = [UIColor colorWithRed:51/255.0 green:51/255.0 blue:51/255.0 alpha:1];
    [btn6 addSubview:titleLable6];
    
    self.numberLable6 = [[UILabel alloc]initWithFrame:CGRectMake(ScreenW-140, 0, 100, 44)];
    self.numberLable6.text = [UnityTool getStringValueForConfigurationKey:@"distance"];
    self.numberLable6.textAlignment = NSTextAlignmentRight;
    self.numberLable6.font = [UIFont systemFontOfSize:15];
    self.numberLable6.textColor = [UIColor colorWithRed:51/255.0 green:51/255.0 blue:51/255.0 alpha:0.5];
    [btn6 addSubview:self.numberLable6];
    
    UIImageView *image6 = [[UIImageView alloc]initWithFrame:CGRectMake(ScreenW-35, 17, 10, 10)];
    image6.image = [UIImage imageNamed:@"右点击"];
    [btn6 addSubview:image6];
    
    //运动步距
    UIView *line7 = [[UIView alloc]initWithFrame:CGRectMake(20, 447.5, ScreenW-40, 0.5)];
    line7.backgroundColor = [[UIColor grayColor]colorWithAlphaComponent:0.3];
    [mainScrollView addSubview:line7];
    
    UIButton *btn7 = [[UIButton alloc]initWithFrame:CGRectMake(0, 448, ScreenW, 44)];
    [mainScrollView addSubview:btn7];
    
    UILabel *titleLable7 = [[UILabel alloc]initWithFrame:CGRectMake(20, 0, 100, 44)];
    titleLable7.text = @"运动步距";
    titleLable7.font = [UIFont systemFontOfSize:15];
    titleLable7.textColor = [UIColor colorWithRed:51/255.0 green:51/255.0 blue:51/255.0 alpha:1];
    [btn7 addSubview:titleLable7];
    
    self.numberLable7 = [[UILabel alloc]initWithFrame:CGRectMake(ScreenW-140, 0, 100, 44)];
    self.numberLable7.text = @"10000";
    self.numberLable7.textAlignment = NSTextAlignmentRight;
    self.numberLable7.font = [UIFont systemFontOfSize:15];
    self.numberLable7.textColor = [UIColor colorWithRed:51/255.0 green:51/255.0 blue:51/255.0 alpha:0.5];
    [btn7 addSubview:self.numberLable7];
    
    UIImageView *image7 = [[UIImageView alloc]initWithFrame:CGRectMake(ScreenW-35, 17, 10, 10)];
    image7.image = [UIImage imageNamed:@"右点击"];
    [btn7 addSubview:image7];
    
    UIView *line8 = [[UIView alloc]initWithFrame:CGRectMake(20, 492, ScreenW-40, 0.5)];
    line8.backgroundColor = [[UIColor grayColor]colorWithAlphaComponent:0.3];
    [mainScrollView addSubview:line8];
    
}

- (void)refreshUI
{
    self.idLable.text = [UnityTool  getStringValueForConfigurationKey:kUSER_Name];
    self.numberLable1.text = [UnityTool getStringValueForConfigurationKey:kUSER_Name];
    self.numberLable2.text = [UnityTool getStringValueForConfigurationKey:@"sex"];
    self.numberLable3.text = [UnityTool getStringValueForConfigurationKey:@"born"];
    self.numberLable4.text = [UnityTool getStringValueForConfigurationKey:@"height"];
    self.numberLable5.text =  [UnityTool getStringValueForConfigurationKey:@"Weight"];
    self.numberLable6.text =   [UnityTool getStringValueForConfigurationKey:@"distance"];
}

#pragma mark- ==================点击事件================================
//输入姓名
- (UserNameView *)addView
{
    if (!_addView) {
        _addView = [UserNameView initFromXIB];
        CGRect bounds = _addView.bounds;
        bounds.size.width = KScreenWidth - 20;
        bounds.size.height = 90;
        _addView.bounds = bounds;
        self.addView.layer.cornerRadius = 10;
        self.addView.layer.masksToBounds = YES;
        self.addView.TFname.delegate = self;
        [self.addView.okButton addTarget:self action:@selector(editPersonName) forControlEvents:UIControlEventTouchUpInside];
        
    }
    return _addView;
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    [UnityTool setStringValueForConfigurationKey:kUSER_Name WithValue:[NSString stringWithFormat:@"%@",textField.text]];
    [self refreshUI];
}

-(void)editName
{
    dispatch_async(dispatch_get_main_queue(), ^{
        
        self.numberLable1.text = self.addView.TFname.text;
    });
    //编辑姓名
    __weak typeof (self) weakself = self;
    [self pop:self.addView locationType:RMPopControllerLocationTypeTop andDismiss:^{
        [UnityTool setStringValueForConfigurationKey:kUSER_Name WithValue:[NSString stringWithFormat:@"%@",self.addView.TFname.text]];
        [weakself refreshUI];
    }];
}
-(void)editPersonName{
    //清空输入框文字
//    [self.addView.TFname setText:nil];
    //失去第一响应者
    [self.addView.TFname resignFirstResponder];
    [self.addView.TFname resignFirstResponder];    [self popViewDismiss];
    
}
//性别
-(void)edtSex
{
    NSArray *QArray=[[NSArray alloc]initWithObjects:@"男",@"女",@"未知", nil];
    
    SSPopup* selection=[[SSPopup alloc]init];
    selection.backgroundColor=[UIColor colorWithWhite:0.00 alpha:0.4];
    
    selection.frame = CGRectMake(0,0,self.view.frame.size.width,self.view.frame.size.height);
    selection.SSPopupDelegate=self;
    [self.view  addSubview:selection];
    
    [selection CreateTableview:QArray withSender:self.view  withTitle:@"设置性别" setCompletionBlock:^(int tag){
        
        if (tag == 0) {
            
            [UnityTool setStringValueForConfigurationKey:@"sex" WithValue:[NSString stringWithFormat:@"男"]];
        }else if (tag == 1){
             [UnityTool setStringValueForConfigurationKey:@"sex" WithValue:[NSString stringWithFormat:@"女"]];
        }else
        {
            [UnityTool setStringValueForConfigurationKey:@"sex" WithValue:[NSString stringWithFormat:@"未知"]];
        }
        [self refreshUI];
        
    }];
    
    
    
}
//设置出生年月
-(void)editBorn
{
    
    self.pickerView = [[XYZPickerView alloc] initWithFrame:CGRectMake(0, 0, ScreenW, 270) withType:XYZPickerTypeCutom titile:@"出生" Array1:@[@"1990",@"1991",@"1992",@"1993",@"1994",@"1995",@"1996",@"1997",@"1998",@"1999"] withArray2:@[@"1",@"2",@"3",@"4",@"5",@"6",@"7",@"8",@"9",@"10",@"11",@"12"] withArray3:@[@"1",@"2",@"3",@"4",@"5",@"6",@"7",@"8",@"9",@"10",@"11",@"12"]];
    self.pickerView.delegate = self;
   [self.pickerView showPickerView];
    
}
- (void)xyzPickerView:(XYZPickerView *)pickerView pickerTime:(NSString *)time
{
    [UnityTool shareInstance];
    [UnityTool setStringValueForConfigurationKey:@"born" WithValue:time];
   
    [self  refreshUI];
}
//设置身高
-(void)editHeight
{
    NSArray *QArray=[[NSArray alloc]initWithObjects:@"160",@"165",@"170",@"175",@"180",@"185",@"190",@"195",@"200", nil];
    
    SSPopup* selection=[[SSPopup alloc]init];
    selection.backgroundColor=[UIColor colorWithWhite:0.00 alpha:0.4];
    
    selection.frame = CGRectMake(0,0,self.view.frame.size.width,self.view.frame.size.height);
    selection.SSPopupDelegate=self;
    [self.view  addSubview:selection];
    
    [selection CreateTableview:QArray withSender:self.view  withTitle:@"设置身高" setCompletionBlock:^(int tag){
        
        NSLog(@"Tag--->%d",tag);
        [UnityTool shareInstance];
        [UnityTool setStringValueForConfigurationKey:@"height" WithValue:[NSString stringWithFormat:@"%ldcm",(tag*5)+160]];
        [self refreshUI];

    }];

}
//体重
-(void)editWeight
{
    NSArray *QArray=[[NSArray alloc]initWithObjects:@"40",@"45",@"50",@"55",@"60",@"65",@"70",@"75", nil];
    
    SSPopup* selection=[[SSPopup alloc]init];
    selection.backgroundColor=[UIColor colorWithWhite:0.00 alpha:0.4];
    
    selection.frame = CGRectMake(0,0,self.view.frame.size.width,self.view.frame.size.height);
    selection.SSPopupDelegate=self;
    [self.view  addSubview:selection];
    
    [selection CreateTableview:QArray withSender:self.view  withTitle:@"设置体重" setCompletionBlock:^(int tag){
        
        NSLog(@"Tag--->%d",tag);
        [UnityTool shareInstance];
        [UnityTool setStringValueForConfigurationKey:@"Weight" WithValue:[NSString stringWithFormat:@"%ldkg",(tag*5)+40]];
        [self refreshUI];
        
    }];

}
// 步距
-(void)editdistance
{
    NSArray *QArray=[[NSArray alloc]initWithObjects:@"1000",@"2000",@"3000",@"4000",@"5000",@"6000",@"7000",@"8000",@"9000", nil];
    
    SSPopup* selection=[[SSPopup alloc]init];
    selection.backgroundColor=[UIColor colorWithWhite:0.00 alpha:0.4];
    
    selection.frame = CGRectMake(0,0,self.view.frame.size.width,self.view.frame.size.height);
    selection.SSPopupDelegate=self;
    [self.view  addSubview:selection];
    
    [selection CreateTableview:QArray withSender:self.view  withTitle:@"设置步距" setCompletionBlock:^(int tag){
        
        NSLog(@"Tag--->%d",tag);
        [UnityTool shareInstance];
        [UnityTool setStringValueForConfigurationKey:@"distance" WithValue:[NSString stringWithFormat:@"%ldm",(tag+1)*1000]];
        [self refreshUI];
        
    }];

    
    
}
#pragma mark- actionSheet delegate=============================================================
// 点击头像按钮选取用户头像
- (void)takePictureClick:(id)sender {
    
    UIActionSheet* actionSheet = [[UIActionSheet alloc]
                                  initWithTitle:@"请选择文件来源"
                                  delegate:self
                                  cancelButtonTitle:@"取消"
                                  destructiveButtonTitle:nil
                                  otherButtonTitles:@"拍照",@"相册",nil];
    [actionSheet showInView:self.view];
    
}
#pragma mark- actionSheet delegate=================================
- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex {
    
    if (buttonIndex!=2) {
        UIImagePickerController *_imagePicker = [[UIImagePickerController alloc] init];
        _imagePicker.delegate = self;
        _imagePicker.allowsEditing = NO;
        if (buttonIndex==0) {
            if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
                _imagePicker.delegate = self;
                _imagePicker.sourceType = UIImagePickerControllerSourceTypeCamera;
                _imagePicker.allowsEditing = YES;
                [self presentViewController:_imagePicker animated:YES completion:nil];
            }
        } else if (buttonIndex==1) {
            if ([UIImagePickerController isSourceTypeAvailable: UIImagePickerControllerSourceTypeSavedPhotosAlbum]) {
                _imagePicker.sourceType = UIImagePickerControllerSourceTypeSavedPhotosAlbum;
                [self presentViewController:_imagePicker animated:YES completion:nil];
            } else if([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypePhotoLibrary]) {
                _imagePicker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
                [self presentViewController:_imagePicker animated:YES completion:nil];
            }
        }
    }
}

#pragma mark - image picker============================================
- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)imagePickerController:(UIImagePickerController *)picker
        didFinishPickingImage:(UIImage *)selectedImage
                  editingInfo:(NSDictionary *)editingInfo {
    //    _avatarImage = selectedImage;
    [_userImageButton setImage:selectedImage forState:UIControlStateNormal];
    [_userImageButton setTitle:nil forState:UIControlStateNormal];
    [self dismissViewControllerAnimated:YES completion:nil];
    //    [self uploadCertifyWithImage:_avatarImage];
}

@end
