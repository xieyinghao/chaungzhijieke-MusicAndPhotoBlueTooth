//
//  CaculatorButton.m
//  PayDemo
//
//  Created by xieyingze on 16/8/2.
//  Copyright © 2016年 xieyingze. All rights reserved.
//

#import "CaculatorButton.h"
#import "UIImage+ColorImage.h"

@implementation CaculatorButton

- (void)drawRect:(CGRect)rect
{
    [super drawRect:rect];
    
    [self setBackgroundImage:[UIImage returnImageFromColor:[UIColor whiteColor]] forState:UIControlStateNormal];
    [self setBackgroundImage:[UIImage returnImageFromColor:[UIColor colorWithRed:0.8308 green:0.8484 blue:0.8875 alpha:1.0]] forState:UIControlStateHighlighted];
    self.layer.borderColor = [UIColor grayColor].CGColor;
    self.layer.borderWidth = 0.5;
    self.layer.cornerRadius = 2;
    self.layer.masksToBounds = YES;
}

@end
