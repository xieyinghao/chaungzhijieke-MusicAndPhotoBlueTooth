//
//  UIButton+Style.m
//  PayDemo
//
//  Created by xieyingze on 16/8/10.
//  Copyright © 2016年 xieyingze. All rights reserved.
//

#import "UIButton+Style.h"
#import "AppColor.h"
#import "UIImage+ColorImage.h"

@implementation UIButton (Style)

//不可用状态
- (void)setDisableStyle
{
    self.backgroundColor = Button_Gray;
    [self setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    self.layer.cornerRadius = 2;
    self.enabled = NO;
}

//默认风格
- (void)setDefaultStyle
{
    self.backgroundColor = Button_Blue;
    [self setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    self.layer.cornerRadius = 2;
    self.enabled = YES;
}

- (void)setSearchStyleOfSelected
{
    self.selected = YES;
    [self setBackgroundImage:[UIImage returnImageFromColor:Button_Blue] forState:UIControlStateSelected];
    [self setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];
    self.layer.borderColor = Button_Blue.CGColor;
    self.layer.borderWidth = 1;
    self.layer.cornerRadius = 4;
    self.layer.masksToBounds = YES;
}

- (void)setSearchStyleOfNormal
{
    self.selected = NO;
    [self setBackgroundImage:[UIImage returnImageFromColor:[UIColor whiteColor]] forState:UIControlStateNormal];
    [self setTitleColor:XYZRGB16Color(0x666666) forState:UIControlStateNormal];
    self.layer.borderColor = [UIColor grayColor].CGColor;
    self.layer.borderWidth = 0.5;
    self.layer.cornerRadius = 4;
    self.layer.masksToBounds = YES;
}

- (void)setSearTimeStyle
{
    [self setBackgroundImage:[UIImage returnImageFromColor:[UIColor whiteColor]] forState:UIControlStateNormal];
    [self setTitleColor:XYZRGB16Color(0x666666) forState:UIControlStateNormal];
    self.layer.borderColor = [UIColor grayColor].CGColor;
    self.layer.borderWidth = 0.5;
    self.layer.cornerRadius = 4;
    self.layer.masksToBounds = YES;
}

@end
