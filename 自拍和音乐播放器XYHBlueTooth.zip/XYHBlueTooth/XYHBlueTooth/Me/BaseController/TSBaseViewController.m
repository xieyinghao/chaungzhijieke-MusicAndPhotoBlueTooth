//
//  TSBaseViewController.m
//  PayDemo
//
//  Created by xieyingze on 16/8/6.
//  Copyright © 2016年 xieyingze. All rights reserved.
//

#import "TSBaseViewController.h"
#import "RMPopController.h"

@interface TSBaseViewController ()

@property (nonatomic, strong)RMPopController *PopController;


@end

@implementation TSBaseViewController

#pragma mark - LifeCycle

-(void)modal:(UIViewController *)modal from:(UIViewController*)from
{
    UINavigationController* navi = [[UINavigationController alloc]initWithRootViewController:modal];
    [from presentViewController:navi animated:YES completion:nil];
}

-(void)push:(UIViewController*)push from:(UINavigationController *)from
{
    [push setHidesBottomBarWhenPushed:YES];
    [from pushViewController:push animated:YES];
}

#pragma mark - LifeCycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self baseConfiguration];
}

#pragma mark - configuration

- (void)baseConfiguration
{
    self.navigationController.navigationBar.translucent = NO;
    
    self.navigationController.interactivePopGestureRecognizer.delegate = (id)self;
    
    self.view.backgroundColor = View_BaseBackGround;
    
    self.navigationItem.leftBarButtonItem.tintColor = [UIColor lightGrayColor];
    
//    [self setClearBottomStyle];
    
    [self setupBackNaviBar];
}

- (void)setClearBottomStyle
{
    if ([self.navigationController.navigationBar respondsToSelector:@selector( setBackgroundImage:forBarMetrics:)]){
        
        NSArray *list = self.navigationController.navigationBar.subviews;
        
        for (id obj in list) {
            if ([obj isKindOfClass:[UIImageView class]]) {
                UIImageView *imageView = (UIImageView *)obj;
                imageView.hidden = YES;
            }
        }
    }
}

-(void)setupBackNaviBar
{
    UIBarButtonItem *backBar = [[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"back"] style:UIBarButtonItemStylePlain target:self action:@selector(onNaviBack)];
    
    [self.navigationItem setLeftBarButtonItem:backBar];
}

-(void)onNaviBack
{
    [self finishNavi];
}

-(void)finishNavi
{
    if (self.navigationController) {
        if ([self.navigationController.viewControllers firstObject] == self) {
            [self dismissViewControllerAnimated:YES completion:nil];
        }else {
            [self.navigationController popViewControllerAnimated:YES];
        }
    }else {
        [self dismissViewControllerAnimated:YES completion:nil];
    }
}

-(void)hideNaviBack
{
    self.navigationItem.hidesBackButton = YES;
    self.navigationItem.leftBarButtonItem = nil;
    self.navigationItem.backBarButtonItem = nil;
}


#pragma mark - BaseMethods

-(UIAlertView*)alert:(NSString*)error andTitle:(NSString*)title
{
    UIAlertView* alert = [[UIAlertView alloc]initWithTitle:title message:error delegate:self cancelButtonTitle:@"我知道了" otherButtonTitles:nil];
    [alert show];
    return alert;
}

-(UIAlertView*)alert:(NSString*)error andTitle:(NSString*)title cancelButtonTitle:(NSString *)cancelBtn andOtherButtonTitles:(NSString *)otherBtn
{
    UIAlertView* alert = [[UIAlertView alloc]initWithTitle:title message:error delegate:self cancelButtonTitle:cancelBtn otherButtonTitles:otherBtn, nil];
    [alert show];
    return alert;
}


#pragma mark - popup

- (void)pop:(UIView*)view locationType:(RMPopControllerLocationType)locationType andDismiss:(dispatch_block_t) block
{
    [self.PopController pop:view locationType:locationType andDismiss:block];
}

-(void)popViewDismiss
{
    [self.PopController dismissDefault];
}

#pragma mark - Delegate


#pragma mark - EventResponse


#pragma mark - GettersAndSetters

- (RMPopController *)PopController
{
    if (_PopController == nil) {
        
        _PopController = [[RMPopController alloc]init];
        _PopController.popAnimationType = RMPopControllerAnimationTypeZoom;
        
    }
    return _PopController;
}


@end
