//
//  AppURL.h
//  GTG
//
//  Created by xieyingze on 16/7/13.
//  Copyright © 2016年 xieyingze. All rights reserved.
//

#ifndef AppURL_h
#define AppURL_h

#endif /* AppURL_h */
