//
//  AppColor.h
//  AnXinBank
//
//  Created by xieyingze on 16/1/31.
//  Copyright © 2016年 xieyingze. All rights reserved.
//

#ifndef AppColor_h
#define AppColor_h

#define XYZRGB16Color(rgbValue) [UIColor colorWithRed:((float)((rgbValue & 0xFF0000) >> 16))/255.0 green:((float)((rgbValue & 0xFF00) >> 8))/255.0 blue:((float)(rgbValue & 0xFF))/255.0 alpha:1.0]

/**
 *  View背景颜色
 */
#define View_BaseBackGround     XYZRGB16Color(0xefefef)

#define View_Blue               XYZRGB16Color(0x218DE4)

/**
 *  Navigation颜色
 */
#define Navigation_Back            XYZRGB16Color(0xffffff)

#define Navigation_Background      XYZRGB16Color(0xE15722)

/**
 *  BUtton背景颜色
 */
#define Button_Blue                 XYZRGB16Color(0x218DE4)
#define Button_Orage                XYZRGB16Color(0xE15722)
#define Button_Gray                 XYZRGB16Color(0x969696)

/**
 *  Font字体颜色
 */
#define FONT_SPECAIL            XYZRGB16Color(0x333333)

#define FONT_NORMAL             XYZRGB16Color(0x666666)

#define FONT_TIP                XYZRGB16Color(0x999999)

/**
 *  TabBar背景颜色
 */
//#define kTBMainTabBarViewBackground [UIColor colorWithRed:248/255.0 green:248/255.0 blue:248/255.0 alpha:1]
#define TabBarViewBackground     XYZRGB16Color(0xE15722)

#endif /* AppColor_h */
