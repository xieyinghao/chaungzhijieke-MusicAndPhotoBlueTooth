//
//  AppUserDefault.h
//  AnXinBank
//
//  Created by xieyingze on 16/1/31.
//  Copyright © 2016年 xieyingze. All rights reserved.
//

#ifndef AppUserDefault_h
#define AppUserDefault_h

/**
 *  基本配置
 */
#define kShowTime   3

#endif /* AppUserDefault_h */
