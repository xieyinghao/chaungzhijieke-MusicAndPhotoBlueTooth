//
//  RMPopController.m
//  XHQB
//
//  Created by 陈波 on 15/9/14.
//  Copyright (c) 2015年 chenbo. All rights reserved.
//

#import "RMPopController.h"

#define kScreenWidth        [UIScreen mainScreen].bounds.size.width
#define kScreenHeight       [UIScreen mainScreen].bounds.size.height

@interface RMPopController ()

@property (nonatomic) CGPoint showPoint;
@property (nonatomic, strong) UIButton *handerView;
@property (nonatomic, retain) UIView* popView;

@property (nonatomic, copy) dispatch_block_t dismissBlock;

@end

@implementation RMPopController

-(UIButton*)handerView
{
    if(_handerView == nil)
    {
        _handerView = [UIButton buttonWithType:UIButtonTypeCustom];
        [_handerView setFrame:[UIScreen mainScreen].bounds];
        [_handerView addTarget:self action:@selector(dismiss) forControlEvents:UIControlEventTouchUpInside];
//        [_handerView addTarget:self action:@selector(dismiss) forControlEvents:UIControlEventTouchUpInside];
    }
    return _handerView;
}

-(void)resetLayout
{
    CGRect frame = _popView.frame;
    frame.origin = _showPoint;
    _popView.frame = frame;
}


#pragma mark - pop

-(void)pop:(UIView*)view locationType:(RMPopControllerLocationType)locationType andDismiss:(dispatch_block_t)block
{
    if(view == nil)
        return ;
    _locationType = locationType;
    _popView = view;
    _popView.layer.cornerRadius = 6;
    _popView.layer.masksToBounds = YES;
    _dismissBlock = block;
    
    _popView.layer.cornerRadius = 5.0f;
    
    [self showDefault];
}

-(void)dismiss
{
    [self dismissDefault];
}


-(void)showDefault
{
    UIWindow *window = [UIApplication sharedApplication].keyWindow;
    [window addSubview:self.handerView];
    [self.handerView addSubview:_popView];
    
    if (_locationType == RMPopControllerLocationTypeCenter) {
        //_popView.center = self.handerView.center;
        CGRect targetRect = [UIScreen mainScreen].bounds;
        
        targetRect.origin.x = (targetRect.size.width - _popView.bounds.size.width)/2;
        targetRect.origin.y = (targetRect.size.height - _popView.bounds.size.height)/2;
        targetRect.size = _popView.bounds.size;
        
        CGRect startRect = targetRect;
        startRect.origin.x = [UIScreen mainScreen].bounds.size.width/2;
        startRect.origin.y = [UIScreen mainScreen].bounds.size.height/2;
        startRect.size.width = 0;
        startRect.size.height = 0;
        
        _popView.frame = targetRect;
    }
    else if (_locationType == RMPopControllerLocationTypeTop){
        _popView.frame = CGRectMake((kScreenWidth - _popView.bounds.size.width)/2, (kScreenHeight - _popView.bounds.size.height)/2 - 100, _popView.bounds.size.width, _popView.bounds.size.height);
    }
    
    _popView.alpha = 0.0f;
    
    [_handerView setBackgroundColor:[UIColor colorWithWhite:0.5f alpha:0.0f]];
    
    if (_popAnimationType == RMPopControllerAnimationTypeZoom)
    {
        _popView.alpha = 1.0f;
        [_handerView setBackgroundColor:[UIColor colorWithWhite:0.3 alpha:0.5]];
        [self transformAanimationWithView:_popView duration:0.25];
    }
    else
    {
        [UIView animateWithDuration:0.25f delay:0.f options:UIViewAnimationOptionCurveEaseInOut animations:^{
            //_popView.frame = targetRect;
            _popView.alpha = 1.0f;
            //[_handerView setBackgroundColor:[UIColor colorWithWhite:0.5f alpha:0.9f]];
            [_handerView setBackgroundColor:[UIColor colorWithWhite:0.3 alpha:0.5]];
        } completion:^(BOOL finished) {
            //_popView.frame = targetRect;
        }];
    }
}

-(void)dismissDefault
{
    CGRect startRect = CGRectZero;
    startRect.origin.x = [UIScreen mainScreen].bounds.size.width/2;
    startRect.origin.y = [UIScreen mainScreen].bounds.size.height/2;
    startRect.size.width = 0;
    startRect.size.height = 0;
    
    [UIView animateWithDuration:0.3f delay:0.f options:UIViewAnimationOptionCurveEaseInOut animations:^{
        //_popView.frame = startRect;
        _popView.alpha = 0.0f;
        [_handerView setBackgroundColor:[UIColor colorWithWhite:0.9f alpha:0.0f]];
    } completion:^(BOOL finished) {
        //[_popView removeFromSuperview];
        [self.handerView removeFromSuperview];
        if(_dismissBlock!=nil)
            _dismissBlock();
    }];
}

- (void)transformAanimationWithView:(UIView *)view duration:(CFTimeInterval)duration{
    
    CAKeyframeAnimation * animation;
    animation = [CAKeyframeAnimation animationWithKeyPath:@"transform"];
    animation.duration = duration;
    animation.removedOnCompletion = NO;
    
    animation.fillMode = kCAFillModeForwards;
    
    NSMutableArray *values = [NSMutableArray array];
    [values addObject:[NSValue valueWithCATransform3D:CATransform3DMakeScale(0.1, 0.1, 1.0)]];
    [values addObject:[NSValue valueWithCATransform3D:CATransform3DMakeScale(1.2, 1.2, 1.0)]];
    //    [values addObject:[NSValue valueWithCATransform3D:CATransform3DMakeScale(0.9, 0.9, 0.9)]];
    [values addObject:[NSValue valueWithCATransform3D:CATransform3DMakeScale(1.0, 1.0, 1.0)]];
    
    animation.values = values;
    animation.timingFunction = [CAMediaTimingFunction functionWithName: @"easeInEaseOut"];
    
    [view.layer addAnimation:animation forKey:nil];
}

@end
