//
//  TSBaseViewController.h
//  PayDemo
//
//  Created by xieyingze on 16/8/6.
//  Copyright © 2016年 xieyingze. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
#import "AppTag.h"
#import "AppURL.h"
#import "AppCode.h"
#import "AppName.h"
#import "AppSize.h"
#import "AppColor.h"
#import "AppDevice.h"
#import "UIButton+Block.h"
#import "Masonry.h"
#import "UIImage+ColorImage.h"
#import "RMPopController.h"

@interface TSBaseViewController : UIViewController

- (void)modal:(UIViewController *)modal from:(UIViewController*)from;
- (void)push:(UIViewController*)push from:(UINavigationController *)from;

- (UIAlertView*)alert:(NSString*)error andTitle:(NSString*)title;
- (UIAlertView*)alert:(NSString*)error andTitle:(NSString*)title cancelButtonTitle:(NSString *)cancelBtn andOtherButtonTitles:(NSString *)otherBtn;

- (void)pop:(UIView*)view locationType:(RMPopControllerLocationType)locationType andDismiss:(dispatch_block_t) block;
- (void)popViewDismiss;

@end
