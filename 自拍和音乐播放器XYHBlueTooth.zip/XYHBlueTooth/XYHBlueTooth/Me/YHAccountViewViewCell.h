//
//  YHAccountViewViewCell.h
//  Fibit
//
//  Created by xieyingze on 16/11/25.
//  Copyright © 2016年 ShenZhenHaoHanCompany. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YHAccountViewViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *icon;
@property (weak, nonatomic) IBOutlet UILabel *textLble;
@property (weak, nonatomic) IBOutlet UILabel *typeLable;

@end
